import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mytimo/main.dart';
import 'package:mytimo/providers/plant_provider.dart';
import 'package:mytimo/providers/scan_provider.dart';
import 'package:mytimo/screens/auth/login_screen.dart';
import 'package:mytimo/screens/landing/landing_screen.dart';
import 'package:mytimo/screens/home/home_screen.dart';
import 'package:mytimo/screens/plant/plant_list_screen.dart';
import 'package:mytimo/screens/plant/plant_detail_screen.dart';
import 'package:mytimo/screens/scan/edit_scan_notes_screen.dart';
import 'package:mytimo/screens/scan/scan_preview_screen.dart';
import 'package:mytimo/screens/scan/scan_history_screen.dart';
import 'package:mytimo/screens/scan/scan_history_detail_screen.dart';
import 'package:provider/provider.dart';

void main() {
  testWidgets('1. Landing Screen UI and Navigation to Login test', (WidgetTester tester) async {
    tester.view.physicalSize = const Size(1080, 2400);
    tester.view.devicePixelRatio = 2.0;
    addTearDown(() => tester.view.resetPhysicalSize());

    await tester.pumpWidget(const MyTimoApp());
    await tester.pumpAndSettle();

    // Verify LandingScreen elements
    expect(find.byType(LandingScreen), findsOneWidget);
    expect(find.text('MyTimo App'), findsOneWidget);
    expect(find.text('Mulai Sekarang'), findsOneWidget);
    expect(find.text('Masuk ke Akun Anda'), findsOneWidget);

    // Navigate to Login
    await tester.tap(find.text('Masuk ke Akun Anda'));
    await tester.pumpAndSettle();

    expect(find.byType(LoginScreen), findsOneWidget);
    expect(find.text('Masuk Akun'), findsOneWidget);
    expect(find.text('Lupa Kata Sandi?'), findsOneWidget);
  });

  testWidgets('2. HomeScreen UI and Metrics test', (WidgetTester tester) async {
    tester.view.physicalSize = const Size(1080, 2400);
    tester.view.devicePixelRatio = 2.0;
    addTearDown(() => tester.view.resetPhysicalSize());

    await tester.pumpWidget(const MyTimoApp());
    await tester.pumpAndSettle();

    // Go to Login
    await tester.tap(find.text('Masuk ke Akun Anda'));
    await tester.pumpAndSettle();

    // Fill form and tap Masuk
    await tester.enterText(find.byType(TextField).first, 'joko@mytimo.id');
    await tester.enterText(find.byType(TextField).last, 'password123');
    await tester.tap(find.text('Masuk'));
    await tester.pump(const Duration(milliseconds: 700));
    await tester.pumpAndSettle();

    // Verify HomeScreen elements matching Screenshot Image 2
    expect(find.byType(HomeScreen), findsOneWidget);
    expect(find.text('Pak Joko Santoso'), findsOneWidget);
    expect(find.text('Pindai Daun Tomat'), findsOneWidget);
    expect(find.text('Total Tanaman'), findsOneWidget);
    expect(find.text('Perlu Rawat'), findsOneWidget);
    expect(find.text('Daun Sehat'), findsWidgets);
    expect(find.text('Menu Utama'), findsOneWidget);
    expect(find.text('Pemeriksaan Terbaru'), findsOneWidget);
  });

  testWidgets('3. Plant Management: List, Detail, Add, Edit, Delete test', (WidgetTester tester) async {
    tester.view.physicalSize = const Size(1080, 2400);
    tester.view.devicePixelRatio = 2.0;
    addTearDown(() => tester.view.resetPhysicalSize());

    final plantProvider = PlantProvider();
    final scanProvider = ScanProvider();

    await tester.pumpWidget(
      MultiProvider(
        providers: [
          ChangeNotifierProvider.value(value: plantProvider),
          ChangeNotifierProvider.value(value: scanProvider),
        ],
        child: const MaterialApp(
          home: PlantListScreen(),
        ),
      ),
    );
    await tester.pumpAndSettle();

    // Verify PlantListScreen elements
    expect(find.text('Daftar Tanaman'), findsOneWidget);
    expect(find.text('Tomat Cherry Blok A'), findsOneWidget);
    expect(find.text('Tomat Servo Bedeng 1'), findsOneWidget);

    // Tap on Tomat Cherry Blok A to open detail
    await tester.tap(find.text('Tomat Cherry Blok A'));
    await tester.pumpAndSettle();

    expect(find.byType(PlantDetailScreen), findsOneWidget);
    expect(find.text('Cherry Tropis'), findsWidgets);
    expect(find.text('Pindai Daun Tanaman Ini'), findsOneWidget);
    expect(find.text('Hapus Data Tanaman'), findsOneWidget);

    // Test Delete Dialog in Plant Detail
    await tester.tap(find.text('Hapus Data Tanaman'));
    await tester.pumpAndSettle();

    expect(find.text('Hapus Data Tanaman?'), findsOneWidget);
    expect(find.text('Batal'), findsOneWidget);
    expect(find.text('Ya, Hapus'), findsOneWidget);

    // Cancel deletion
    await tester.tap(find.text('Batal'));
    await tester.pumpAndSettle();
    expect(find.text('Hapus Data Tanaman?'), findsNothing);
  });

  testWidgets('4. Scan Management Workflow: Preview, Save, Detail, Edit Notes test', (WidgetTester tester) async {
    tester.view.physicalSize = const Size(1080, 2400);
    tester.view.devicePixelRatio = 2.0;
    addTearDown(() => tester.view.resetPhysicalSize());

    final plantProvider = PlantProvider();
    final scanProvider = ScanProvider();
    final samplePlant = plantProvider.allPlants.first;

    await tester.pumpWidget(
      MultiProvider(
        providers: [
          ChangeNotifierProvider.value(value: plantProvider),
          ChangeNotifierProvider.value(value: scanProvider),
        ],
        child: MaterialApp(
          home: ScanPreviewScreen(
            plant: samplePlant,
            imagePath: 'assets/images/hero_tomatoes.webp',
            isAssetImage: true,
          ),
        ),
      ),
    );
    await tester.pumpAndSettle();

    // Verify Preview Screen (Screenshot 2.1)
    expect(find.text('Pratinjau Foto Daun'), findsOneWidget);
    expect(find.text('Kualitas Citra Memenuhi Syarat'), findsOneWidget);
    expect(find.text('Hubungkan ke Tanaman *'), findsOneWidget);
    expect(find.text('Foto Ulang'), findsOneWidget);
    expect(find.text('Lanjut Diagnosis AI'), findsOneWidget);

    // Tap "Lanjut Diagnosis AI" to save
    await tester.tap(find.text('Lanjut Diagnosis AI'));
    await tester.pumpAndSettle();

    // Verify navigating to Scan History Detail Screen (Screenshot 3.2)
    expect(find.byType(ScanHistoryDetailScreen), findsOneWidget);
    expect(find.text('Detail Riwayat Scan'), findsOneWidget);
    expect(find.text('Tanaman & Waktu'), findsOneWidget);
    expect(find.text('Catatan Riwayat'), findsOneWidget);
    expect(find.text('Simpan Perubahan Catatan'), findsOneWidget);
    expect(find.text('Hapus Riwayat Scan Ini'), findsOneWidget);

    // Tap "Simpan Perubahan Catatan" to open EditScanNotesScreen (Screenshot 3.3)
    await tester.tap(find.text('Simpan Perubahan Catatan'));
    await tester.pumpAndSettle();

    expect(find.byType(EditScanNotesScreen), findsOneWidget);
    expect(find.text('Ubah Catatan Riwayat'), findsOneWidget);
    expect(find.text('+ Pemangkasan Daun'), findsOneWidget);
    expect(find.text('+ Semprot Fungisida'), findsOneWidget);

    // Tap quick action chip to append note
    await tester.tap(find.text('+ Pemangkasan Daun'));
    await tester.pumpAndSettle();

    // Tap save
    await tester.tap(find.text('Simpan Perubahan Catatan'));
    await tester.pumpAndSettle();

    // Returned to ScanHistoryDetailScreen
    expect(find.byType(ScanHistoryDetailScreen), findsOneWidget);
  });

  testWidgets('5. Scan History Screen: Search, Filters, Empty State & Delete Modal test', (WidgetTester tester) async {
    tester.view.physicalSize = const Size(1080, 2400);
    tester.view.devicePixelRatio = 2.0;
    addTearDown(() => tester.view.resetPhysicalSize());

    final plantProvider = PlantProvider();
    final scanProvider = ScanProvider();

    await tester.pumpWidget(
      MultiProvider(
        providers: [
          ChangeNotifierProvider.value(value: plantProvider),
          ChangeNotifierProvider.value(value: scanProvider),
        ],
        child: const MaterialApp(
          home: ScanHistoryScreen(),
        ),
      ),
    );
    await tester.pumpAndSettle();

    // Verify initial ScanHistoryScreen elements (Screenshot 2.2)
    expect(find.text('Riwayat Pemindaian'), findsOneWidget);
    expect(find.text('Semua (4)'), findsOneWidget);
    expect(find.text('Early Blight (1)'), findsOneWidget);
    expect(find.text('Late Blight (1)'), findsOneWidget);

    // Search for non-existent plant e.g. "Tomat Roma" (Screenshot 3.1)
    await tester.enterText(find.byType(TextField), 'Tomat Roma');
    await tester.pumpAndSettle();

    // Verify Empty Search State (Screenshot 3.1)
    expect(find.text('Riwayat Tidak Ditemukan'), findsOneWidget);
    expect(find.text('Tips Pencarian Riwayat:'), findsOneWidget);
    expect(find.text('Reset Filter'), findsOneWidget);

    // Tap Reset Filter
    await tester.tap(find.text('Reset Filter'));
    await tester.pumpAndSettle();

    // List is restored
    expect(find.text('Riwayat Tidak Ditemukan'), findsNothing);
    expect(find.text('Early Blight (94.2%)'), findsOneWidget);

    // Open first scan detail
    await tester.tap(find.text('Early Blight (94.2%)'));
    await tester.pumpAndSettle();

    expect(find.byType(ScanHistoryDetailScreen), findsOneWidget);

    // Tap "Hapus Riwayat Scan Ini" to open Delete Modal (Screenshot 4)
    await tester.tap(find.text('Hapus Riwayat Scan Ini'));
    await tester.pumpAndSettle();

    expect(find.text('Hapus Riwayat Scan?'), findsOneWidget);
    expect(find.text('Foto daun, hasil AI, dan catatan tidak dapat dipulihkan.'), findsOneWidget);
    expect(find.text('Batal'), findsOneWidget);
    expect(find.text('Ya, Hapus'), findsOneWidget);

    // Tap "Ya, Hapus"
    await tester.tap(find.text('Ya, Hapus'));
    await tester.pumpAndSettle();

    // Should return to ScanHistoryScreen and item count decreased
    expect(find.byType(ScanHistoryScreen), findsOneWidget);
    expect(scanProvider.totalCount, 3);
  });
}
