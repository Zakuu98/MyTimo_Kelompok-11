import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mytimo/main.dart';
import 'package:mytimo/providers/auth_provider.dart';
import 'package:mytimo/providers/plant_provider.dart';
import 'package:mytimo/providers/scan_provider.dart';
import 'package:mytimo/screens/auth/login_screen.dart';
import 'package:mytimo/screens/auth/register_screen.dart';
import 'package:mytimo/screens/plant/add_edit_plant_screen.dart';
import 'package:mytimo/screens/scan/scan_camera_screen.dart';
import 'package:mytimo/screens/scan/scan_preview_screen.dart';
import 'package:mytimo/utils/form_validators.dart';
import 'package:provider/provider.dart';

void main() {
  group('1. Unit Tests: FormValidators Rules', () {
    test('Email validator rules', () {
      expect(FormValidators.validateEmail(null), 'Email wajib diisi');
      expect(FormValidators.validateEmail(''), 'Email wajib diisi');
      expect(FormValidators.validateEmail('   '), 'Email wajib diisi');
      expect(FormValidators.validateEmail('joko'), 'Format email tidak valid (contoh: nama@email.com)');
      expect(FormValidators.validateEmail('joko@'), 'Format email tidak valid (contoh: nama@email.com)');
      expect(FormValidators.validateEmail('joko@com'), 'Format email tidak valid (contoh: nama@email.com)');
      expect(FormValidators.validateEmail('joko@mytimo.id'), isNull);
      expect(FormValidators.validateEmail('user.test@farm.co.id'), isNull);
    });

    test('Password validator rules for login and register', () {
      expect(FormValidators.validateLoginPassword(null), 'Kata sandi wajib diisi');
      expect(FormValidators.validateLoginPassword(''), 'Kata sandi wajib diisi');
      expect(FormValidators.validateLoginPassword('123'), isNull);

      expect(FormValidators.validateRegisterPassword(null), 'Kata sandi wajib diisi');
      expect(FormValidators.validateRegisterPassword(''), 'Kata sandi wajib diisi');
      expect(FormValidators.validateRegisterPassword('12345'), 'Kata sandi minimal 6 karakter');
      expect(FormValidators.validateRegisterPassword('123456'), isNull);
      expect(FormValidators.validateRegisterPassword('password123'), isNull);
    });

    test('Confirm password validator rules', () {
      expect(FormValidators.validateConfirmPassword(null, 'secret123'), 'Konfirmasi kata sandi wajib diisi');
      expect(FormValidators.validateConfirmPassword('', 'secret123'), 'Konfirmasi kata sandi wajib diisi');
      expect(FormValidators.validateConfirmPassword('wrong', 'secret123'), 'Konfirmasi kata sandi tidak cocok dengan kata sandi');
      expect(FormValidators.validateConfirmPassword('secret123', 'secret123'), isNull);
    });

    test('Name and plant fields validator rules', () {
      expect(FormValidators.validateName(null), 'Nama lengkap wajib diisi');
      expect(FormValidators.validateName('   '), 'Nama lengkap wajib diisi');
      expect(FormValidators.validateName('A'), 'Nama terlalu pendek (minimal 2 karakter)');
      expect(FormValidators.validateName('Pak Joko'), isNull);

      expect(FormValidators.validatePlantName(null), 'Nama tanaman tidak boleh kosong');
      expect(FormValidators.validatePlantName('   '), 'Nama tanaman tidak boleh kosong');
      expect(FormValidators.validatePlantName('TC'), 'Nama tanaman minimal 3 karakter');
      expect(FormValidators.validatePlantName('Tomat Cherry'), isNull);

      expect(FormValidators.validatePlantVariety('   '), 'Varietas tidak boleh hanya berisi spasi');
      expect(FormValidators.validatePlantVariety(''), isNull);
      expect(FormValidators.validatePlantVariety('Gustavi F1'), isNull);

      expect(FormValidators.validatePlantLocation(null), 'Lokasi tidak boleh kosong');
      expect(FormValidators.validatePlantLocation('   '), 'Lokasi tidak boleh kosong');
      expect(FormValidators.validatePlantLocation('Greenhouse 1'), isNull);
    });
  });

  group('2. Widget Tests: Login Form Validation', () {
    testWidgets('Login validation blocks empty & invalid formats', (tester) async {
      tester.view.physicalSize = const Size(1080, 2400);
      tester.view.devicePixelRatio = 2.0;
      addTearDown(() => tester.view.resetPhysicalSize());

      final authProvider = AuthProvider();

      await tester.pumpWidget(
        ChangeNotifierProvider.value(
          value: authProvider,
          child: const MaterialApp(home: LoginScreen()),
        ),
      );
      await tester.pumpAndSettle();

      // Tap Masuk without filling anything
      await tester.tap(find.text('Masuk'));
      await tester.pumpAndSettle();

      // Error messages appear inline under text fields
      expect(find.text('Email wajib diisi'), findsOneWidget);
      expect(find.text('Kata sandi wajib diisi'), findsOneWidget);

      // Enter invalid email
      await tester.enterText(find.byType(TextFormField).first, 'budi');
      await tester.enterText(find.byType(TextFormField).last, 'pass123');
      await tester.tap(find.text('Masuk'));
      await tester.pumpAndSettle();

      expect(find.text('Format email tidak valid (contoh: nama@email.com)'), findsOneWidget);
      expect(find.text('Kata sandi wajib diisi'), findsNothing);
    });
  });

  group('3. Widget Tests: Register Form Validation', () {
    testWidgets('Sign up validation checks required fields and password matching', (tester) async {
      tester.view.physicalSize = const Size(1080, 2400);
      tester.view.devicePixelRatio = 2.0;
      addTearDown(() => tester.view.resetPhysicalSize());

      final authProvider = AuthProvider();

      await tester.pumpWidget(
        ChangeNotifierProvider.value(
          value: authProvider,
          child: const MaterialApp(home: RegisterScreen()),
        ),
      );
      await tester.pumpAndSettle();

      // Tap Daftar without input
      await tester.tap(find.text('Daftar'));
      await tester.pumpAndSettle();

      expect(find.text('Nama lengkap wajib diisi'), findsOneWidget);
      expect(find.text('Email wajib diisi'), findsOneWidget);
      expect(find.text('Kata sandi wajib diisi'), findsOneWidget);
      expect(find.text('Konfirmasi kata sandi wajib diisi'), findsOneWidget);

      // Fill mismatched passwords and short password
      await tester.enterText(find.byType(TextFormField).at(0), 'Petani Budi');
      await tester.enterText(find.byType(TextFormField).at(1), 'budi@mytimo.id');
      await tester.enterText(find.byType(TextFormField).at(2), '123');
      await tester.enterText(find.byType(TextFormField).at(3), '123456');
      await tester.tap(find.text('Daftar'));
      await tester.pumpAndSettle();

      expect(find.text('Kata sandi minimal 6 karakter'), findsOneWidget);
      expect(find.text('Konfirmasi kata sandi tidak cocok dengan kata sandi'), findsOneWidget);
    });
  });

  group('4. Widget Tests: Plant Management Validation', () {
    testWidgets('Add/Edit plant rejects whitespace-only inputs', (tester) async {
      tester.view.physicalSize = const Size(1080, 2400);
      tester.view.devicePixelRatio = 2.0;
      addTearDown(() => tester.view.resetPhysicalSize());

      final plantProvider = PlantProvider();

      await tester.pumpWidget(
        ChangeNotifierProvider.value(
          value: plantProvider,
          child: const MaterialApp(home: AddEditPlantScreen()),
        ),
      );
      await tester.pumpAndSettle();

      // Enter only spaces in plant name and location
      await tester.enterText(find.byType(TextFormField).at(0), '    ');
      await tester.enterText(find.byType(TextFormField).at(3), '    ');

      final initialPlantCount = plantProvider.allPlants.length;

      // Tap Save
      await tester.tap(find.text('✓ Simpan Data Tanaman'));
      await tester.pumpAndSettle();

      // Error appears and plant count did not increase
      expect(find.text('Nama tanaman tidak boleh kosong'), findsOneWidget);
      expect(find.text('Lokasi tidak boleh kosong'), findsOneWidget);
      expect(plantProvider.allPlants.length, initialPlantCount);
    });
  });

  group('5. Widget Tests: Scan Management Validation & Empty Plant Safeguard', () {
    testWidgets('Scan camera rejects scan when no plant exists', (tester) async {
      tester.view.physicalSize = const Size(1080, 2400);
      tester.view.devicePixelRatio = 2.0;
      addTearDown(() => tester.view.resetPhysicalSize());

      // Empty PlantProvider
      final emptyPlantProvider = PlantProvider();
      while (emptyPlantProvider.allPlants.isNotEmpty) {
        emptyPlantProvider.deletePlant(emptyPlantProvider.allPlants.first.id);
      }

      await tester.pumpWidget(
        ChangeNotifierProvider.value(
          value: emptyPlantProvider,
          child: const MaterialApp(home: ScanCameraScreen()),
        ),
      );
      await tester.pumpAndSettle();

      // Tap shutter button
      await tester.tap(find.byIcon(Icons.image_outlined));
      await tester.pumpAndSettle();

      // Warning snackbar appears
      expect(
        find.text('Silakan tambahkan data tanaman terlebih dahulu sebelum memindai.'),
        findsOneWidget,
      );
    });

    testWidgets('Scan preview rejects saving when imagePath is empty', (tester) async {
      tester.view.physicalSize = const Size(1080, 2400);
      tester.view.devicePixelRatio = 2.0;
      addTearDown(() => tester.view.resetPhysicalSize());

      final plantProvider = PlantProvider();
      final scanProvider = ScanProvider();
      final samplePlant = plantProvider.allPlants.first;

      await tester.pumpWidget(
        MultiProvider(
          providers: [
            ChangeNotifierProvider.value(value: plantProvider),
            ChangeNotifierProvider.value(value: scanProvider),
          ],
          child: MaterialApp(
            home: ScanPreviewScreen(
              plant: samplePlant,
              imagePath: '   ', // Invalid empty path
              isAssetImage: false,
            ),
          ),
        ),
      );
      await tester.pumpAndSettle();

      final initialScanCount = scanProvider.allScans.length;

      // Tap Lanjut Diagnosis AI
      await tester.tap(find.text('Lanjut Diagnosis AI'));
      await tester.pumpAndSettle();

      // Error snackbar appears and scan record not saved
      expect(
        find.text('Foto daun belum tersedia. Silakan ambil foto ulang.'),
        findsOneWidget,
      );
      expect(scanProvider.allScans.length, initialScanCount);
    });
  });

  group('6. Widget Tests: Responsive Mobile Web Layout at Desktop Resolution', () {
    testWidgets('MaterialApp builder constrains max width to 480px on desktop screen', (tester) async {
      // Simulate Desktop 1920x1080 Chrome browser window
      tester.view.physicalSize = const Size(1920, 1080);
      tester.view.devicePixelRatio = 1.0;
      addTearDown(() => tester.view.resetPhysicalSize());

      await tester.pumpWidget(const MyTimoApp());
      await tester.pumpAndSettle();

      // Find ConstrainedBox in root builder
      final constrainedBoxes = tester.widgetList<ConstrainedBox>(find.byType(ConstrainedBox));
      final rootMobileConstraint = constrainedBoxes.firstWhere(
        (box) => box.constraints.maxWidth == 480,
      );

      expect(rootMobileConstraint, isNotNull);
      expect(rootMobileConstraint.constraints.maxWidth, 480);
    });
  });
}
