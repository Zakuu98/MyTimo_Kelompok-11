import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mytimo/models/plant_model.dart';
import 'package:mytimo/models/scan_record_model.dart';
import 'package:mytimo/providers/plant_provider.dart';
import 'package:mytimo/providers/scan_provider.dart';
import 'package:mytimo/screens/plant/plant_detail_screen.dart';
import 'package:mytimo/screens/scan/scan_history_detail_screen.dart';
import 'package:provider/provider.dart';

void main() {
  group('Detail Tanaman Revision & Health Score Tests', () {
    testWidgets(
      'Kondisi 1: Tanaman baru tanpa riwayat scan tidak menampilkan foto tomat dan skor belum tersedia',
      (WidgetTester tester) async {
        tester.view.physicalSize = const Size(1080, 2400);
        tester.view.devicePixelRatio = 2.0;
        addTearDown(() => tester.view.resetPhysicalSize());

        final plantProvider = PlantProvider();
        final scanProvider = ScanProvider();

        // Buat tanaman baru tanpa riwayat pemindaian
        final newPlant = PlantModel(
          id: 'plant_test_new',
          name: 'Tomat Unggul Baru',
          variety: 'Beefsteak F1',
          plantedDate: DateTime.now().subtract(const Duration(days: 10)),
          location: 'Bedeng Uji 05',
          notes: 'Tanaman uji tanpa pemindaian',
          status: 'Belum Ada Data',
          diseaseTag: null,
          healthScore: null,
          imagePath: '',
          isAssetImage: false,
        );
        plantProvider.addPlant(newPlant);

        await tester.pumpWidget(
          MultiProvider(
            providers: [
              ChangeNotifierProvider.value(value: plantProvider),
              ChangeNotifierProvider.value(value: scanProvider),
            ],
            child: const MaterialApp(
              home: PlantDetailScreen(plantId: 'plant_test_new'),
            ),
          ),
        );
        await tester.pumpAndSettle();

        // 1. Verifikasi placeholder foto muncul dan tidak ada foto tomat
        expect(find.text('Belum ada foto tanaman'), findsOneWidget);
        expect(find.text('hero_tomatoes.webp'), findsNothing);

        // 2. Verifikasi status banner: belum ada hasil pemindaian (bukan 'Kondisi Tanaman Sehat')
        expect(find.text('Belum ada hasil pemindaian'), findsOneWidget);
        expect(find.text('Kondisi Tanaman Sehat'), findsNothing);

        // 3. Verifikasi skor kesehatan di spec card: belum tersedia (bukan '92%' atau '100%')
        expect(find.text('Belum tersedia'), findsOneWidget);
        expect(find.textContaining('92%'), findsNothing);
        expect(find.textContaining('100%'), findsNothing);

        // 4. Verifikasi section scan terakhir kosong
        expect(find.text('Belum ada pemindaian untuk tanaman ini'), findsOneWidget);
      },
    );

    testWidgets(
      'Kondisi 2: Tanaman dengan riwayat scan tanpa diagnosis valid menampilkan status diagnosis belum tersedia',
      (WidgetTester tester) async {
        tester.view.physicalSize = const Size(1080, 2400);
        tester.view.devicePixelRatio = 2.0;
        addTearDown(() => tester.view.resetPhysicalSize());

        final plantProvider = PlantProvider();
        final scanProvider = ScanProvider();

        // Buat tanaman
        final plantWithScan = PlantModel(
          id: 'plant_with_scan',
          name: 'Tomat Cherry Scan Baru',
          variety: 'Cherry Merah',
          plantedDate: DateTime.now().subtract(const Duration(days: 15)),
          location: 'Greenhouse C',
          notes: 'Baru saja difoto',
          status: 'Belum Ada Data',
          diseaseTag: null,
          healthScore: null,
          imagePath: '',
          isAssetImage: false,
        );
        plantProvider.addPlant(plantWithScan);

        // Tambahkan scan record untuk tanaman ini namun TANPA hasil diagnosis AI (belum terintegrasi)
        final scanRecord = ScanRecordModel(
          id: 'scan_no_ai',
          plantId: 'plant_with_scan',
          plantName: 'Tomat Cherry Scan Baru',
          imagePath: 'assets/images/disease_late_blight.webp',
          isAssetImage: true,
          scannedAt: DateTime.now(),
          notes: 'Foto daun bawah tanaman.',
          status: 'Menunggu Diagnosis AI',
          diagnosisName: null,
          confidence: null,
          severity: 'Menunggu',
        );
        scanProvider.addScan(scanRecord);

        await tester.pumpWidget(
          MultiProvider(
            providers: [
              ChangeNotifierProvider.value(value: plantProvider),
              ChangeNotifierProvider.value(value: scanProvider),
            ],
            child: const MaterialApp(
              home: PlantDetailScreen(plantId: 'plant_with_scan'),
            ),
          ),
        );
        await tester.pumpAndSettle();

        // 1. Header tetap placeholder (foto scan tidak dijadikan foto utama tanpa logika)
        expect(find.text('Belum ada foto tanaman'), findsOneWidget);

        // 2. Status banner menjelaskan diagnosis belum tersedia
        expect(find.text('Diagnosis belum tersedia • Menunggu analisis'), findsOneWidget);

        // 3. Skor kesehatan menampilkan diagnosis belum tersedia (bukan skor palsu)
        expect(find.text('Diagnosis belum tersedia'), findsOneWidget);

        // 4. Foto riwayat pemindaian tetap dapat dilihat di bagian Scan Terakhir
        expect(find.text('Menunggu Diagnosis AI • Foto tersimpan'), findsOneWidget);

        // 5. Klik Scan Terakhir untuk membuka detail riwayat scan
        await tester.tap(find.text('Menunggu Diagnosis AI • Foto tersimpan'));
        await tester.pumpAndSettle();

        expect(find.byType(ScanHistoryDetailScreen), findsOneWidget);
        expect(find.text('Detail Riwayat Scan'), findsOneWidget);
        expect(find.text('Foto daun bawah tanaman.'), findsOneWidget);
      },
    );

    testWidgets(
      'Kondisi 3: Tanaman dengan diagnosis valid menampilkan informasi diagnosis tersimpan',
      (WidgetTester tester) async {
        tester.view.physicalSize = const Size(1080, 2400);
        tester.view.devicePixelRatio = 2.0;
        addTearDown(() => tester.view.resetPhysicalSize());

        final plantProvider = PlantProvider();
        final scanProvider = ScanProvider();

        // plant_001 memiliki scan_001 (Early Blight, confidence 94.2, severity: Sedang)
        await tester.pumpWidget(
          MultiProvider(
            providers: [
              ChangeNotifierProvider.value(value: plantProvider),
              ChangeNotifierProvider.value(value: scanProvider),
            ],
            child: const MaterialApp(
              home: PlantDetailScreen(plantId: 'plant_001'),
            ),
          ),
        );
        await tester.pumpAndSettle();

        // Header tetap placeholder
        expect(find.text('Belum ada foto tanaman'), findsOneWidget);

        // Status banner berdasarkan diagnosis tersimpan yang valid
        expect(find.text('Early Blight • Dalam Rawat'), findsOneWidget);

        // Skor kesehatan menampilkan data confidence tersimpan yang valid
        expect(find.text('94% • Sedang'), findsOneWidget);

        // Scan terakhir menampilkan info Early Blight
        expect(find.text('Early Blight • 94.2% akurat'), findsOneWidget);
      },
    );
  });
}
