/// Helper validator terpusat untuk seluruh form input di MyTimo
class FormValidators {
  FormValidators._();

  /// Regex standar untuk memvalidasi format email
  static final RegExp _emailRegExp = RegExp(
    r'^[a-zA-Z0-9.!#$%&’*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)+$',
  );

  /// Validasi Email
  static String? validateEmail(String? value) {
    if (value == null || value.trim().isEmpty) {
      return 'Email wajib diisi';
    }
    final trimmed = value.trim();
    if (!_emailRegExp.hasMatch(trimmed)) {
      return 'Format email tidak valid (contoh: nama@email.com)';
    }
    return null;
  }

  /// Validasi Password Login (wajib diisi)
  static String? validateLoginPassword(String? value) {
    if (value == null || value.isEmpty) {
      return 'Kata sandi wajib diisi';
    }
    return null;
  }

  /// Validasi Password Pendaftaran (wajib diisi & minimal 6 karakter)
  static String? validateRegisterPassword(String? value, {int minLength = 6}) {
    if (value == null || value.isEmpty) {
      return 'Kata sandi wajib diisi';
    }
    if (value.length < minLength) {
      return 'Kata sandi minimal $minLength karakter';
    }
    return null;
  }

  /// Validasi Konfirmasi Password
  static String? validateConfirmPassword(String? value, String password) {
    if (value == null || value.isEmpty) {
      return 'Konfirmasi kata sandi wajib diisi';
    }
    if (value != password) {
      return 'Konfirmasi kata sandi tidak cocok dengan kata sandi';
    }
    return null;
  }

  /// Validasi Nama Lengkap Pengguna
  static String? validateName(String? value) {
    if (value == null || value.trim().isEmpty) {
      return 'Nama lengkap wajib diisi';
    }
    if (value.trim().length < 2) {
      return 'Nama terlalu pendek (minimal 2 karakter)';
    }
    return null;
  }

  /// Validasi Nama Tanaman
  static String? validatePlantName(String? value) {
    if (value == null || value.trim().isEmpty) {
      return 'Nama tanaman tidak boleh kosong';
    }
    if (value.trim().length < 3) {
      return 'Nama tanaman minimal 3 karakter';
    }
    return null;
  }

  /// Validasi Varietas Tanaman (opsional, tetapi jika diisi tidak boleh hanya spasi)
  static String? validatePlantVariety(String? value) {
    if (value != null && value.isNotEmpty && value.trim().isEmpty) {
      return 'Varietas tidak boleh hanya berisi spasi';
    }
    return null;
  }

  /// Validasi Lokasi Tanaman
  static String? validatePlantLocation(String? value) {
    if (value == null || value.trim().isEmpty) {
      return 'Lokasi tidak boleh kosong';
    }
    return null;
  }
}
