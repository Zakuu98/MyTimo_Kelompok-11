import 'package:flutter/material.dart';
import '../models/plant_model.dart';

/// State management untuk modul Pengelolaan Tanaman (Plant Management - Anggota 1)
class PlantProvider extends ChangeNotifier {
  final List<PlantModel> _plants = [
    PlantModel(
      id: 'plant_001',
      name: 'Tomat Cherry Blok A',
      variety: 'Cherry Tropis',
      plantedDate: DateTime.now().subtract(const Duration(days: 63)),
      location: 'Greenhouse 1 • Rak B3',
      notes: 'Daun bawah mulai membaik pasca pemangkasan.',
      status: 'Perlu Rawat',
      diseaseTag: 'Early Blight',
      healthScore: 88,
      imagePath: 'assets/images/hero_tomatoes.webp',
      isAssetImage: true,
    ),
    PlantModel(
      id: 'plant_002',
      name: 'Tomat Servo Bedeng 1',
      variety: 'Servo F1',
      plantedDate: DateTime.now().subtract(const Duration(days: 25)),
      location: 'Lahan Terbuka • Bedeng 01',
      notes: 'Pertumbuhan vegetatif optimal, siap masuk fase berbunga.',
      status: 'Sehat',
      diseaseTag: 'Sehat',
      healthScore: 95,
      imagePath: 'assets/images/disease_septoria.webp',
      isAssetImage: true,
    ),
    PlantModel(
      id: 'plant_003',
      name: 'Tomat Mawar Bedeng 4',
      variety: 'Mawar Lokal',
      plantedDate: DateTime.now().subtract(const Duration(days: 50)),
      location: 'Lahan Terbuka • Bedeng 04',
      notes: 'Bercak basah kehitaman terdeteksi pada kanopi bagian bawah.',
      status: 'Parah',
      diseaseTag: 'Late Blight',
      healthScore: 65,
      imagePath: 'assets/images/disease_late_blight.webp',
      isAssetImage: true,
    ),
    PlantModel(
      id: 'plant_004',
      name: 'Tomat Sayur Blok C',
      variety: 'Gustavi F1',
      plantedDate: DateTime.now().subtract(const Duration(days: 22)),
      location: 'Lahan Timur • Bedeng 02',
      notes: 'Bibit semai 25 hari, media tanah kompos organik.',
      status: 'Belum Ada Data',
      diseaseTag: null,
      healthScore: null,
      imagePath: '',
      isAssetImage: false,
    ),
  ];

  String _searchQuery = '';
  String _selectedFilter = 'Semua';

  List<PlantModel> get allPlants => List.unmodifiable(_plants);
  String get searchQuery => _searchQuery;
  String get selectedFilter => _selectedFilter;

  int get totalCount => _plants.length;
  int get healthyCount => _plants.where((p) => p.status == 'Sehat').length;
  int get needCareCount => _plants.where((p) => p.status == 'Perlu Rawat').length;
  int get severeCount => _plants.where((p) => p.status == 'Parah').length;

  List<PlantModel> get filteredPlants {
    return _plants.where((plant) {
      final matchesSearch = _searchQuery.isEmpty ||
          plant.name.toLowerCase().contains(_searchQuery.toLowerCase()) ||
          plant.variety.toLowerCase().contains(_searchQuery.toLowerCase()) ||
          plant.location.toLowerCase().contains(_searchQuery.toLowerCase());

      final matchesFilter = _selectedFilter == 'Semua' || plant.status == _selectedFilter;

      return matchesSearch && matchesFilter;
    }).toList();
  }

  void setSearchQuery(String query) {
    _searchQuery = query;
    notifyListeners();
  }

  void setFilter(String filter) {
    _selectedFilter = filter;
    notifyListeners();
  }

  PlantModel? getPlantById(String id) {
    try {
      return _plants.firstWhere((p) => p.id == id);
    } catch (_) {
      return null;
    }
  }

  void addPlant(PlantModel plant) {
    _plants.insert(0, plant);
    notifyListeners();
  }

  void updatePlant(PlantModel updated) {
    final index = _plants.indexWhere((p) => p.id == updated.id);
    if (index != -1) {
      _plants[index] = updated;
      notifyListeners();
    }
  }

  void deletePlant(String plantId) {
    _plants.removeWhere((p) => p.id == plantId);
    notifyListeners();
  }
}
