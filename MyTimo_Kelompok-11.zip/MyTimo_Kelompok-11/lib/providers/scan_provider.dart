import 'package:flutter/material.dart';
import '../models/scan_record_model.dart';

/// State management untuk modul Pemindaian & Riwayat Scan (Scan Management - Anggota 1)
class ScanProvider extends ChangeNotifier {
  final List<ScanRecordModel> _scans = [
    ScanRecordModel(
      id: 'scan_001',
      plantId: 'plant_001',
      plantName: 'Tomat Cherry Blok A',
      imagePath: 'assets/images/disease_late_blight.webp',
      isAssetImage: true,
      scannedAt: DateTime(2026, 10, 6, 14, 20),
      notes: 'Bercak baru muncul di 2 daun bagian bawah, segera pangkas dan semprot fungisida tembaga.',
      status: 'Teridentifikasi',
      diagnosisName: 'Early Blight',
      confidence: 94.2,
      severity: 'Sedang',
    ),
    ScanRecordModel(
      id: 'scan_002',
      plantId: 'plant_002',
      plantName: 'Tomat Servo Bedeng 1',
      imagePath: 'assets/images/disease_septoria.webp',
      isAssetImage: true,
      scannedAt: DateTime(2026, 10, 4, 9, 15),
      notes: 'Kondisi daun prima, tidak ada tanda klorosis atau spora jamur.',
      status: 'Sehat',
      diagnosisName: 'Daun Sehat',
      confidence: 98.0,
      severity: 'Sehat',
    ),
    ScanRecordModel(
      id: 'scan_003',
      plantId: 'plant_003',
      plantName: 'Tomat Mawar Bedeng 4',
      imagePath: 'assets/images/disease_late_blight.webp',
      isAssetImage: true,
      scannedAt: DateTime(2026, 10, 1, 16, 35),
      notes: 'Hawar daun basah hitam di bagian pucuk, butuh perlakuan fungisida sistemik.',
      status: 'Teridentifikasi',
      diagnosisName: 'Late Blight',
      confidence: 89.5,
      severity: 'Parah',
    ),
    ScanRecordModel(
      id: 'scan_004',
      plantId: 'plant_001',
      plantName: 'Tomat Cherry Blok A',
      imagePath: 'assets/images/hero_tomatoes.webp',
      isAssetImage: true,
      scannedAt: DateTime(2026, 9, 25, 11, 0),
      notes: 'Pemeriksaan rutin mingguan fase pembungaan.',
      status: 'Sehat',
      diagnosisName: 'Daun Sehat',
      confidence: 99.1,
      severity: 'Sehat',
    ),
  ];

  String _searchQuery = '';
  String? _filterPlantId;
  String _diseaseFilter = 'Semua';
  String _statusFilter = 'Semua Status';
  String _timeRangeFilter = 'Semua Waktu';

  List<ScanRecordModel> get allScans => List.unmodifiable(_scans);
  String get searchQuery => _searchQuery;
  String? get filterPlantId => _filterPlantId;
  String get diseaseFilter => _diseaseFilter;
  String get statusFilter => _statusFilter;
  String get timeRangeFilter => _timeRangeFilter;

  bool get isFilterActive =>
      _searchQuery.isNotEmpty ||
      _filterPlantId != null ||
      _diseaseFilter != 'Semua' ||
      _statusFilter != 'Semua Status' ||
      _timeRangeFilter != 'Semua Waktu';

  int get totalCount => _scans.length;
  int get earlyBlightCount => _scans.where((s) => s.diagnosisName == 'Early Blight').length;
  int get lateBlightCount => _scans.where((s) => s.diagnosisName == 'Late Blight').length;
  int get healthyCount => _scans.where((s) => s.diagnosisName == 'Daun Sehat' || s.status == 'Sehat').length;

  List<ScanRecordModel> get filteredScans {
    final now = DateTime.now();
    return _scans.where((scan) {
      final matchesSearch = _searchQuery.isEmpty ||
          scan.plantName.toLowerCase().contains(_searchQuery.toLowerCase()) ||
          scan.notes.toLowerCase().contains(_searchQuery.toLowerCase()) ||
          (scan.diagnosisName != null &&
              scan.diagnosisName!.toLowerCase().contains(_searchQuery.toLowerCase()));

      final matchesPlant = _filterPlantId == null || scan.plantId == _filterPlantId;

      final matchesDisease = _diseaseFilter == 'Semua' ||
          (scan.diagnosisName != null && scan.diagnosisName!.contains(_diseaseFilter));

      final matchesStatus = _statusFilter == 'Semua Status' || scan.severity == _statusFilter;

      bool matchesTime = true;
      if (_timeRangeFilter == 'Hari Ini') {
        matchesTime = scan.scannedAt.year == now.year &&
            scan.scannedAt.month == now.month &&
            scan.scannedAt.day == now.day;
      } else if (_timeRangeFilter == 'Minggu Ini') {
        matchesTime = now.difference(scan.scannedAt).inDays <= 7;
      } else if (_timeRangeFilter == 'Bulan Ini') {
        matchesTime = scan.scannedAt.year == now.year && scan.scannedAt.month == now.month;
      }

      return matchesSearch && matchesPlant && matchesDisease && matchesStatus && matchesTime;
    }).toList();
  }

  void setSearchQuery(String query) {
    _searchQuery = query;
    notifyListeners();
  }

  void setFilterPlantId(String? plantId) {
    _filterPlantId = plantId;
    notifyListeners();
  }

  void setDiseaseFilter(String filter) {
    _diseaseFilter = filter;
    notifyListeners();
  }

  void setStatusFilter(String status) {
    _statusFilter = status;
    notifyListeners();
  }

  void setTimeRangeFilter(String range) {
    _timeRangeFilter = range;
    notifyListeners();
  }

  void resetFilters() {
    _searchQuery = '';
    _filterPlantId = null;
    _diseaseFilter = 'Semua';
    _statusFilter = 'Semua Status';
    _timeRangeFilter = 'Semua Waktu';
    notifyListeners();
  }

  List<ScanRecordModel> getScansForPlant(String plantId) {
    return _scans.where((s) => s.plantId == plantId).toList();
  }

  ScanRecordModel? getLatestScanForPlant(String plantId) {
    final list = getScansForPlant(plantId);
    if (list.isEmpty) return null;
    list.sort((a, b) => b.scannedAt.compareTo(a.scannedAt));
    return list.first;
  }

  ScanRecordModel? getScanById(String id) {
    try {
      return _scans.firstWhere((s) => s.id == id);
    } catch (_) {
      return null;
    }
  }

  void addScan(ScanRecordModel scan) {
    _scans.insert(0, scan);
    notifyListeners();
  }

  void updateScanNotes(String scanId, String newNotes) {
    final index = _scans.indexWhere((s) => s.id == scanId);
    if (index != -1) {
      _scans[index] = _scans[index].copyWith(notes: newNotes);
      notifyListeners();
    }
  }

  void deleteScan(String scanId) {
    _scans.removeWhere((s) => s.id == scanId);
    notifyListeners();
  }

  void deleteScansByPlantId(String plantId) {
    _scans.removeWhere((s) => s.plantId == plantId);
    notifyListeners();
  }
}
