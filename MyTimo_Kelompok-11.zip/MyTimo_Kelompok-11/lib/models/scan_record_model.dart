/// Entity Model Riwayat Pemindaian untuk modul Scan Management (Anggota 1)
class ScanRecordModel {
  final String id;
  final String plantId;
  final String plantName;
  final String imagePath;
  final bool isAssetImage;
  final DateTime scannedAt;
  final String notes;
  final String status; // 'Menunggu Diagnosis AI', 'Teridentifikasi', 'Sehat'
  final String? diagnosisName; // e.g. 'Early Blight', 'Late Blight', 'Daun Sehat'
  final double? confidence; // e.g. 94.2
  final String severity; // 'Sedang', 'Sehat', 'Parah'

  const ScanRecordModel({
    required this.id,
    required this.plantId,
    required this.plantName,
    required this.imagePath,
    this.isAssetImage = true,
    required this.scannedAt,
    this.notes = '',
    this.status = 'Menunggu Diagnosis AI',
    this.diagnosisName,
    this.confidence,
    this.severity = 'Sedang',
  });

  String get displayTitle {
    if (diagnosisName != null && confidence != null) {
      return '$diagnosisName (${confidence!.toStringAsFixed(1)}%)';
    }
    return diagnosisName ?? 'Pemeriksaan Daun';
  }

  String get formattedDateTime {
    const months = [
      'Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun',
      'Jul', 'Agu', 'Sep', 'Okt', 'Nov', 'Des'
    ];
    final day = scannedAt.day.toString().padLeft(2, '0');
    final month = months[scannedAt.month - 1];
    final year = scannedAt.year;
    final hour = scannedAt.hour.toString().padLeft(2, '0');
    final minute = scannedAt.minute.toString().padLeft(2, '0');
    return '$day $month $year, $hour:$minute';
  }

  String get formattedRelativeDate {
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final scanDay = DateTime(scannedAt.year, scannedAt.month, scannedAt.day);
    final diff = today.difference(scanDay).inDays;

    if (diff == 0) return 'Hari ini';
    if (diff == 1) return 'Kemarin';
    const months = [
      'Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun',
      'Jul', 'Agu', 'Sep', 'Okt', 'Nov', 'Des'
    ];
    return '${scannedAt.day} ${months[scannedAt.month - 1]}';
  }

  ScanRecordModel copyWith({
    String? id,
    String? plantId,
    String? plantName,
    String? imagePath,
    bool? isAssetImage,
    DateTime? scannedAt,
    String? notes,
    String? status,
    String? diagnosisName,
    double? confidence,
    String? severity,
  }) {
    return ScanRecordModel(
      id: id ?? this.id,
      plantId: plantId ?? this.plantId,
      plantName: plantName ?? this.plantName,
      imagePath: imagePath ?? this.imagePath,
      isAssetImage: isAssetImage ?? this.isAssetImage,
      scannedAt: scannedAt ?? this.scannedAt,
      notes: notes ?? this.notes,
      status: status ?? this.status,
      diagnosisName: diagnosisName ?? this.diagnosisName,
      confidence: confidence ?? this.confidence,
      severity: severity ?? this.severity,
    );
  }

  factory ScanRecordModel.fromJson(Map<String, dynamic> json) {
    return ScanRecordModel(
      id: json['id'] as String,
      plantId: json['plantId'] as String,
      plantName: json['plantName'] as String,
      imagePath: json['imagePath'] as String,
      isAssetImage: json['isAssetImage'] as bool? ?? true,
      scannedAt: DateTime.parse(json['scannedAt'] as String),
      notes: json['notes'] as String? ?? '',
      status: json['status'] as String? ?? 'Menunggu Diagnosis AI',
      diagnosisName: json['diagnosisName'] as String?,
      confidence: (json['confidence'] as num?)?.toDouble(),
      severity: json['severity'] as String? ?? 'Sedang',
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'plantId': plantId,
      'plantName': plantName,
      'imagePath': imagePath,
      'isAssetImage': isAssetImage,
      'scannedAt': scannedAt.toIso8601String(),
      'notes': notes,
      'status': status,
      'diagnosisName': diagnosisName,
      'confidence': confidence,
      'severity': severity,
    };
  }
}
