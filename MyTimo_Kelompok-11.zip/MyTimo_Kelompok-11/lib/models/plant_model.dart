/// Entity Model Tanaman Tomat untuk modul Plant Management (Anggota 1)
class PlantModel {
  final String id;
  final String name;
  final String variety;
  final DateTime plantedDate;
  final String location;
  final String notes;
  final String status; // 'Belum Ada Data', 'Sehat', 'Perlu Rawat', 'Parah'
  final String? diseaseTag; // e.g. 'Early Blight', 'Late Blight', 'Septoria', 'Sehat'
  final int? healthScore; // e.g. 88 (nullable bila belum ada diagnosis)
  final String imagePath;
  final bool isAssetImage;

  const PlantModel({
    required this.id,
    required this.name,
    required this.variety,
    required this.plantedDate,
    required this.location,
    required this.notes,
    this.status = 'Belum Ada Data',
    this.diseaseTag,
    this.healthScore,
    this.imagePath = '',
    this.isAssetImage = true,
  });

  /// Menghitung Hari Setelah Tanam (HST)
  int get hst {
    final diff = DateTime.now().difference(plantedDate).inDays;
    return diff >= 0 ? diff : 0;
  }

  String get hstLabel => '$hst HST';

  String get formattedPlantedDate {
    const months = [
      'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni',
      'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'
    ];
    final day = plantedDate.day.toString().padLeft(2, '0');
    final month = months[plantedDate.month - 1];
    final year = plantedDate.year;
    return '$day $month $year';
  }

  String get formattedPlantedDateShort {
    const months = [
      'Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun',
      'Jul', 'Agu', 'Sep', 'Okt', 'Nov', 'Des'
    ];
    final day = plantedDate.day.toString().padLeft(2, '0');
    final month = months[plantedDate.month - 1];
    final year = plantedDate.year;
    return '$day $month $year';
  }

  PlantModel copyWith({
    String? id,
    String? name,
    String? variety,
    DateTime? plantedDate,
    String? location,
    String? notes,
    String? status,
    String? diseaseTag,
    int? healthScore,
    String? imagePath,
    bool? isAssetImage,
  }) {
    return PlantModel(
      id: id ?? this.id,
      name: name ?? this.name,
      variety: variety ?? this.variety,
      plantedDate: plantedDate ?? this.plantedDate,
      location: location ?? this.location,
      notes: notes ?? this.notes,
      status: status ?? this.status,
      diseaseTag: diseaseTag ?? this.diseaseTag,
      healthScore: healthScore ?? this.healthScore,
      imagePath: imagePath ?? this.imagePath,
      isAssetImage: isAssetImage ?? this.isAssetImage,
    );
  }

  factory PlantModel.fromJson(Map<String, dynamic> json) {
    return PlantModel(
      id: json['id'] as String,
      name: json['name'] as String,
      variety: json['variety'] as String? ?? 'Tomat Lokal',
      plantedDate: DateTime.parse(json['plantedDate'] as String),
      location: json['location'] as String,
      notes: json['notes'] as String? ?? '',
      status: json['status'] as String? ?? 'Belum Ada Data',
      diseaseTag: json['diseaseTag'] as String?,
      healthScore: json['healthScore'] as int?,
      imagePath: json['imagePath'] as String? ?? '',
      isAssetImage: json['isAssetImage'] as bool? ?? true,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'variety': variety,
      'plantedDate': plantedDate.toIso8601String(),
      'location': location,
      'notes': notes,
      'status': status,
      'diseaseTag': diseaseTag,
      'healthScore': healthScore,
      'imagePath': imagePath,
      'isAssetImage': isAssetImage,
    };
  }
}
