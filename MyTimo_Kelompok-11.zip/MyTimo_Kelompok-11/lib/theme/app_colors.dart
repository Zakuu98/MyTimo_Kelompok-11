import 'package:flutter/material.dart';

/// Design tokens warna MyTimo sesuai pembaruan UI Figma 2026
class AppColors {
  AppColors._();

  // Primary Brand Colors (Farm / Agriculture Green)
  static const Color primaryGreen = Color(0xFF2E7D32);
  static const Color primaryGreenDark = Color(0xFF1B5E20);
  static const Color primaryGreenLight = Color(0xFF4CAF50);
  static const Color primaryGreenSoft = Color(0xFFD4EAD9);
  static const Color primaryGreenText = Color(0xFF1E6F29);

  // Tomato & Scanner Accent Colors
  static const Color tomatoRed = Color(0xFFE53935);
  static const Color tomatoRedDark = Color(0xFFC62828);
  static const Color tomatoRedLight = Color(0xFFFFEBEE);
  static const Color tomatoBanner = Color(0xFFE04332);
  static const Color tomatoBannerDark = Color(0xFFCC3324);
  static const Color orangeAccent = Color(0xFFF95B3D);
  static const Color orangeDeep = Color(0xFFE84118);

  // Warning & Weather
  static const Color warningOrange = Color(0xFFF57C00);
  static const Color warningOrangeLight = Color(0xFFFFF3E0);

  // Status Badge Colors
  static const Color greenBadgeBackground = Color(0xFFE8F5E9);
  static const Color greenBadgeText = Color(0xFF2E7D32);
  static const Color yellowBadgeBackground = Color(0xFFFFF8E1);
  static const Color yellowBadgeText = Color(0xFFD97706);
  static const Color redBadgeBackground = Color(0xFFFFEBEE);
  static const Color redBadgeText = Color(0xFFD32F2F);

  // Neutrals & Backgrounds
  static const Color background = Color(0xFFF8FAF8);
  static const Color surface = Color(0xFFFFFFFF);
  static const Color cardShadow = Color(0x0A000000);
  static const Color border = Color(0xFFE2E8F0);
  static const Color borderFocused = Color(0xFF2E7D32);
  static const Color inputBorderLight = Color(0xFFFFCDD2);
  static const Color divider = Color(0xFFEEEEEE);

  // Text Colors
  static const Color textPrimary = Color(0xFF1A1C1E);
  static const Color textSecondary = Color(0xFF6B7280);
  static const Color textMuted = Color(0xFF9CA3AF);
  static const Color textWhite = Color(0xFFFFFFFF);

  // Gradients
  static const LinearGradient primaryGreenGradient = LinearGradient(
    colors: [Color(0xFF1E7C2B), Color(0xFF2E8B38), Color(0xFF38A144)],
    begin: Alignment.topCenter,
    end: Alignment.bottomCenter,
  );

  static const LinearGradient orangeScannerGradient = LinearGradient(
    colors: [Color(0xFFF95B3D), Color(0xFFE84118)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static const LinearGradient homeHeaderGradient = LinearGradient(
    colors: [Color(0xFF1E7C2B), Color(0xFF2E8B38)],
    begin: Alignment.topCenter,
    end: Alignment.bottomCenter,
  );

  static const LinearGradient scanBannerGradient = LinearGradient(
    colors: [Color(0xFF1E7C2B), Color(0xFF388E3C)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static const LinearGradient floatingScanGradient = LinearGradient(
    colors: [Color(0xFFF95B3D), Color(0xFFE84118)],
    begin: Alignment.topCenter,
    end: Alignment.bottomCenter,
  );
}
