import 'package:flutter/material.dart';

/// Widget Reusable untuk menampilkan Badge/Pill Status Tanaman & Riwayat Pemindaian
/// Hasil refactoring Temuan Audit 1 (Eliminasi duplikasi kode & standardisasi warna status).
class StatusBadge extends StatelessWidget {
  final String status;
  final String? customLabel;
  final bool isSmall;
  final BorderRadius? borderRadius;

  const StatusBadge({
    super.key,
    required this.status,
    this.customLabel,
    this.isSmall = false,
    this.borderRadius,
  });

  @override
  Widget build(BuildContext context) {
    final style = _resolveStyle(status);

    return Container(
      padding: EdgeInsets.symmetric(
        horizontal: isSmall ? 8 : 10,
        vertical: isSmall ? 3 : 5,
      ),
      decoration: BoxDecoration(
        color: style.backgroundColor,
        borderRadius: borderRadius ??
            BorderRadius.circular(isSmall ? 6 : 8),
      ),
      child: Text(
        customLabel ?? style.defaultLabel,
        style: TextStyle(
          color: style.textColor,
          fontSize: isSmall ? 10.5 : 11.5,
          fontWeight: FontWeight.w700,
        ),
      ),
    );
  }

  static _BadgeStyle _resolveStyle(String status) {
    final cleanStatus = status.trim();

    if (cleanStatus == 'Sehat' || cleanStatus == 'Daun Sehat') {
      return const _BadgeStyle(
        backgroundColor: Color(0xFFDCFCE7),
        textColor: Color(0xFF15803D),
        defaultLabel: 'Sehat',
      );
    } else if (cleanStatus == 'Parah' || cleanStatus == 'Late Blight') {
      return const _BadgeStyle(
        backgroundColor: Color(0xFFFEE2E2),
        textColor: Color(0xFFB91C1C),
        defaultLabel: 'Parah',
      );
    } else if (cleanStatus == 'Perlu Rawat' || cleanStatus == 'Sedang' || cleanStatus == 'Early Blight') {
      return const _BadgeStyle(
        backgroundColor: Color(0xFFFEF3C7),
        textColor: Color(0xFFB45309),
        defaultLabel: 'Perlu Rawat',
      );
    } else if (cleanStatus == 'Septoria') {
      return const _BadgeStyle(
        backgroundColor: Color(0xFFFFEBEE),
        textColor: Color(0xFFE53935),
        defaultLabel: 'Septoria',
      );
    } else if (cleanStatus == 'Menunggu' || cleanStatus == 'Menunggu Diagnosis AI') {
      return const _BadgeStyle(
        backgroundColor: Color(0xFFEFF6FF),
        textColor: Color(0xFF1D4ED8),
        defaultLabel: 'Menunggu',
      );
    } else {
      return const _BadgeStyle(
        backgroundColor: Color(0xFFF1F5F9),
        textColor: Color(0xFF64748B),
        defaultLabel: 'Belum Dipindai',
      );
    }
  }
}

class _BadgeStyle {
  final Color backgroundColor;
  final Color textColor;
  final String defaultLabel;

  const _BadgeStyle({
    required this.backgroundColor,
    required this.textColor,
    required this.defaultLabel,
  });
}
