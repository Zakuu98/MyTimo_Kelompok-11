import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../models/plant_model.dart';
import '../../models/scan_record_model.dart';
import '../../providers/plant_provider.dart';
import '../../providers/scan_provider.dart';
import '../../theme/app_colors.dart';
import '../../theme/app_sizes.dart';
import 'scan_history_detail_screen.dart';

/// Halaman Pratinjau Foto Daun sesuai Screenshot 2.1
class ScanPreviewScreen extends StatefulWidget {
  final PlantModel plant;
  final String imagePath;
  final bool isAssetImage;

  const ScanPreviewScreen({
    super.key,
    required this.plant,
    required this.imagePath,
    this.isAssetImage = false,
  });

  @override
  State<ScanPreviewScreen> createState() => _ScanPreviewScreenState();
}

class _ScanPreviewScreenState extends State<ScanPreviewScreen> {
  late PlantModel _currentPlant;
  late final TextEditingController _notesController;
  bool _isSaving = false;

  @override
  void initState() {
    super.initState();
    _currentPlant = widget.plant;
    _notesController = TextEditingController(
      text: 'Bercak cincin kecokelatan di daun bawah ke-3',
    );
  }

  @override
  void dispose() {
    _notesController.dispose();
    super.dispose();
  }

  void _showPlantPicker() {
    final plants = context.read<PlantProvider>().allPlants;
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (ctx) {
        return SafeArea(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Center(
                  child: Container(
                    width: 40,
                    height: 4,
                    decoration: BoxDecoration(
                      color: AppColors.divider,
                      borderRadius: BorderRadius.circular(2),
                    ),
                  ),
                ),
                const SizedBox(height: 16),
                const Text(
                  'Hubungkan ke Tanaman',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800),
                ),
                const SizedBox(height: 12),
                ...plants.map((p) => ListTile(
                      leading: Container(
                        padding: const EdgeInsets.all(8),
                        decoration: const BoxDecoration(
                          color: AppColors.greenBadgeBackground,
                          shape: BoxShape.circle,
                        ),
                        child: const Icon(Icons.spa_outlined, color: AppColors.primaryGreen, size: 20),
                      ),
                      title: Text(p.name, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14)),
                      subtitle: Text('${p.variety} • ${p.location}', style: const TextStyle(fontSize: 12)),
                      trailing: _currentPlant.id == p.id
                          ? const Icon(Icons.check_circle_rounded, color: AppColors.primaryGreen)
                          : null,
                      onTap: () {
                        setState(() {
                          _currentPlant = p;
                        });
                        Navigator.pop(ctx);
                      },
                    )),
              ],
            ),
          ),
        );
      },
    );
  }

  void _proceedDiagnosis() {
    // Validasi 1: Pastikan foto daun valid
    if (widget.imagePath.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Foto daun belum tersedia. Silakan ambil foto ulang.'),
          backgroundColor: AppColors.tomatoRed,
        ),
      );
      return;
    }

    // Validasi 2: Pastikan tanaman telah dipilih dan memiliki ID valid
    if (_currentPlant.id.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Silakan pilih tanaman yang terhubung terlebih dahulu.'),
          backgroundColor: AppColors.tomatoRed,
        ),
      );
      return;
    }

    setState(() => _isSaving = true);

    final cleanNotes = _notesController.text.trim();
    final newScan = ScanRecordModel(
      id: 'scan_${DateTime.now().millisecondsSinceEpoch}',
      plantId: _currentPlant.id,
      plantName: _currentPlant.name,
      imagePath: widget.imagePath,
      isAssetImage: widget.isAssetImage,
      scannedAt: DateTime.now(),
      notes: cleanNotes.isEmpty
          ? 'Bercak baru pada daun bagian bawah.'
          : cleanNotes,
      status: 'Menunggu Diagnosis AI',
      diagnosisName: null,
      confidence: null,
      severity: 'Menunggu',
    );

    context.read<ScanProvider>().addScan(newScan);

    setState(() => _isSaving = false);

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Foto berhasil disimpan untuk tanaman "${_currentPlant.name}"'),
        backgroundColor: AppColors.primaryGreen,
      ),
    );

    // Navigate to Scan History Detail Screen
    Navigator.of(context).pushReplacement(
      MaterialPageRoute(
        builder: (_) => ScanHistoryDetailScreen(scanId: newScan.id),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF8FAF8),
      appBar: PreferredSize(
        preferredSize: const Size.fromHeight(60),
        child: Container(
          decoration: const BoxDecoration(
            gradient: AppColors.homeHeaderGradient,
          ),
          child: SafeArea(
            child: Row(
              children: [
                IconButton(
                  icon: const Icon(Icons.arrow_back_rounded, color: Colors.white),
                  onPressed: () => Navigator.pop(context),
                ),
                const Text(
                  'Pratinjau Foto Daun',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 18,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Image Preview Container with Corner Brackets Overlay
            Container(
              width: double.infinity,
              height: 220,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(22),
                boxShadow: const [
                  BoxShadow(
                    color: Color(0x10000000),
                    blurRadius: 10,
                    offset: Offset(0, 4),
                  ),
                ],
              ),
              child: Stack(
                fit: StackFit.expand,
                alignment: Alignment.center,
                children: [
                  ClipRRect(
                    borderRadius: BorderRadius.circular(22),
                    child: widget.isAssetImage
                        ? Image.asset(widget.imagePath, fit: BoxFit.cover)
                        : kIsWeb
                            ? Image.network(widget.imagePath, fit: BoxFit.cover)
                            : Image.file(File(widget.imagePath), fit: BoxFit.cover),
                  ),

                  // Framing Guide White Brackets Overlay
                  Positioned.fill(
                    child: Padding(
                      padding: const EdgeInsets.all(24),
                      child: Stack(
                        children: [
                          _buildBracket(top: 0, left: 0, isTop: true, isLeft: true),
                          _buildBracket(top: 0, right: 0, isTop: true, isLeft: false),
                          _buildBracket(bottom: 0, left: 0, isTop: false, isLeft: true),
                          _buildBracket(bottom: 0, right: 0, isTop: false, isLeft: false),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),

            // Green Success Banner: "Kualitas Citra Memenuhi Syarat"
            Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
              decoration: BoxDecoration(
                color: const Color(0xFFE8F5E9),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: const Color(0xFFC8E6C9)),
              ),
              child: Row(
                children: [
                  Container(
                    width: 32,
                    height: 32,
                    decoration: const BoxDecoration(
                      color: AppColors.primaryGreen,
                      shape: BoxShape.circle,
                    ),
                    child: const Icon(Icons.check_rounded, color: Colors.white, size: 20),
                  ),
                  const SizedBox(width: 12),
                  const Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Kualitas Citra Memenuhi Syarat',
                          style: TextStyle(
                            fontSize: 13,
                            fontWeight: FontWeight.w800,
                            color: Color(0xFF1B5E20),
                          ),
                        ),
                        SizedBox(height: 2),
                        Text(
                          'Resolusi 1080×1080 • Format JPEG • Fokus Daun Baik',
                          style: TextStyle(
                            fontSize: 11,
                            color: Color(0xFF2E7D32),
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 18),

            // Field: "Hubungkan ke Tanaman *"
            const Text(
              'Hubungkan ke Tanaman *',
              style: TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w700,
                color: AppColors.textPrimary,
              ),
            ),
            const SizedBox(height: 8),
            GestureDetector(
              onTap: _showPlantPicker,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(AppSizes.radiusL),
                  border: Border.all(color: AppColors.inputBorderLight, width: 1.2),
                ),
                child: Row(
                  children: [
                    const Icon(Icons.spa_outlined, color: AppColors.textMuted, size: 20),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        _currentPlant.name,
                        style: const TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w700,
                          color: AppColors.textPrimary,
                        ),
                      ),
                    ),
                    const Icon(Icons.keyboard_arrow_down_rounded, color: AppColors.textMuted),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 18),

            // Field: "Catatan Kondisi Daun"
            const Text(
              'Catatan Kondisi Daun',
              style: TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w700,
                color: AppColors.textPrimary,
              ),
            ),
            const SizedBox(height: 8),
            TextField(
              controller: _notesController,
              maxLines: 3,
              decoration: InputDecoration(
                hintText: 'Tuliskan catatan kondisi daun...',
                hintStyle: const TextStyle(color: AppColors.textMuted, fontSize: 13.5),
                contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(AppSizes.radiusL),
                  borderSide: const BorderSide(color: AppColors.inputBorderLight, width: 1.2),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(AppSizes.radiusL),
                  borderSide: const BorderSide(color: AppColors.primaryGreen, width: 1.5),
                ),
              ),
            ),
            const SizedBox(height: 24),

            // Action Buttons: Foto Ulang & Lanjut Diagnosis AI ->
            Row(
              children: [
                Expanded(
                  flex: 1,
                  child: SizedBox(
                    height: 50,
                    child: OutlinedButton(
                      onPressed: () => Navigator.pop(context),
                      style: OutlinedButton.styleFrom(
                        side: const BorderSide(color: Color(0xFFC8E6C9), width: 1.2),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(AppSizes.radiusFull),
                        ),
                      ),
                      child: const Text(
                        'Foto Ulang',
                        style: TextStyle(
                          color: AppColors.primaryGreen,
                          fontSize: 14,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  flex: 2,
                  child: SizedBox(
                    height: 50,
                    child: ElevatedButton(
                      onPressed: _isSaving ? null : _proceedDiagnosis,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppColors.primaryGreen,
                        foregroundColor: Colors.white,
                        elevation: 0,
                        padding: const EdgeInsets.symmetric(horizontal: 10),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(AppSizes.radiusFull),
                        ),
                      ),
                      child: _isSaving
                          ? const SizedBox(
                              width: 22,
                              height: 22,
                              child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2.5),
                            )
                          : const FittedBox(
                              fit: BoxFit.scaleDown,
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Text(
                                    'Lanjut Diagnosis AI',
                                    style: TextStyle(fontSize: 14.5, fontWeight: FontWeight.w700),
                                  ),
                                  SizedBox(width: 6),
                                  Icon(Icons.arrow_forward_rounded, size: 18),
                                ],
                              ),
                            ),
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 32),
          ],
        ),
      ),
    );
  }

  Widget _buildBracket({
    double? top,
    double? bottom,
    double? left,
    double? right,
    required bool isTop,
    required bool isLeft,
  }) {
    return Positioned(
      top: top,
      bottom: bottom,
      left: left,
      right: right,
      child: Container(
        width: 24,
        height: 24,
        decoration: BoxDecoration(
          border: Border(
            top: isTop ? const BorderSide(color: Colors.white, width: 2.5) : BorderSide.none,
            bottom: !isTop ? const BorderSide(color: Colors.white, width: 2.5) : BorderSide.none,
            left: isLeft ? const BorderSide(color: Colors.white, width: 2.5) : BorderSide.none,
            right: !isLeft ? const BorderSide(color: Colors.white, width: 2.5) : BorderSide.none,
          ),
          borderRadius: BorderRadius.only(
            topLeft: isTop && isLeft ? const Radius.circular(8) : Radius.zero,
            topRight: isTop && !isLeft ? const Radius.circular(8) : Radius.zero,
            bottomLeft: !isTop && isLeft ? const Radius.circular(8) : Radius.zero,
            bottomRight: !isTop && !isLeft ? const Radius.circular(8) : Radius.zero,
          ),
        ),
      ),
    );
  }
}
