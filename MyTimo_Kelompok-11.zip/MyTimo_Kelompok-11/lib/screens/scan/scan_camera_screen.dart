import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';
import '../../models/plant_model.dart';
import '../../providers/plant_provider.dart';
import '../../theme/app_colors.dart';
import '../../theme/app_sizes.dart';
import 'scan_preview_screen.dart';

/// Halaman Kamera & Pemilihan Foto dengan Framing Guide sesuai Screenshot 1
class ScanCameraScreen extends StatefulWidget {
  final PlantModel? selectedPlant;

  const ScanCameraScreen({super.key, this.selectedPlant});

  @override
  State<ScanCameraScreen> createState() => _ScanCameraScreenState();
}

class _ScanCameraScreenState extends State<ScanCameraScreen> {
  final ImagePicker _picker = ImagePicker();
  PlantModel? _targetPlant;
  bool _isLoading = false;
  bool _isFlashOn = false;

  @override
  void initState() {
    super.initState();
    _targetPlant = widget.selectedPlant;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_targetPlant == null) {
        final plants = context.read<PlantProvider>().allPlants;
        if (plants.isNotEmpty) {
          setState(() {
            _targetPlant = plants.first;
          });
        }
      }
    });
  }

  void _showPlantPicker() {
    final plants = context.read<PlantProvider>().allPlants;
    if (plants.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Belum ada data tanaman. Silakan tambahkan tanaman terlebih dahulu.'),
          backgroundColor: AppColors.tomatoRed,
        ),
      );
      return;
    }

    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (ctx) {
        return SafeArea(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Center(
                  child: Container(
                    width: 40,
                    height: 4,
                    decoration: BoxDecoration(
                      color: AppColors.divider,
                      borderRadius: BorderRadius.circular(2),
                    ),
                  ),
                ),
                const SizedBox(height: 16),
                const Text(
                  'Pilih Tanaman Target Pemindaian',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800),
                ),
                const SizedBox(height: 12),
                ...plants.map((p) => ListTile(
                      leading: Container(
                        padding: const EdgeInsets.all(8),
                        decoration: const BoxDecoration(
                          color: AppColors.greenBadgeBackground,
                          shape: BoxShape.circle,
                        ),
                        child: const Icon(Icons.spa_outlined, color: AppColors.primaryGreen, size: 20),
                      ),
                      title: Text(p.name, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14)),
                      subtitle: Text('${p.variety} • ${p.location}', style: const TextStyle(fontSize: 12)),
                      trailing: _targetPlant?.id == p.id
                          ? const Icon(Icons.check_circle_rounded, color: AppColors.primaryGreen)
                          : null,
                      onTap: () {
                        setState(() {
                          _targetPlant = p;
                        });
                        Navigator.pop(ctx);
                      },
                    )),
              ],
            ),
          ),
        );
      },
    );
  }

  Future<void> _pickImage(ImageSource source) async {
    // Validasi 1: Pengguna harus memilih tanaman sebelum memulai pemindaian
    if (_targetPlant == null) {
      final plants = context.read<PlantProvider>().allPlants;
      if (plants.isNotEmpty) {
        _targetPlant = plants.first;
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Silakan tambahkan data tanaman terlebih dahulu sebelum memindai.'),
            backgroundColor: AppColors.tomatoRed,
          ),
        );
        return;
      }
    }

    try {
      setState(() => _isLoading = true);
      final XFile? image = await _picker.pickImage(
        source: source,
        imageQuality: 85,
        maxWidth: 1200,
      );

      if (!mounted) return;
      setState(() => _isLoading = false);

      // Validasi 2: Pengguna harus mengambil foto atau memilih gambar sebelum melanjutkan
      if (image != null && image.path.isNotEmpty) {
        Navigator.of(context).push(
          MaterialPageRoute(
            builder: (_) => ScanPreviewScreen(
              plant: _targetPlant!,
              imagePath: image.path,
              isAssetImage: false,
            ),
          ),
        );
      } else {
        // Tangani kondisi pengguna membatalkan kamera atau pemilihan gambar
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Pengambilan foto dibatalkan.'),
            duration: Duration(seconds: 2),
          ),
        );
      }
    } catch (e) {
      if (!mounted) return;
      setState(() => _isLoading = false);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Kamera hardware tidak dapat diakses: ${e.toString()}'),
          action: SnackBarAction(
            label: 'Foto Sampel',
            textColor: Colors.white,
            onPressed: () {
              if (_targetPlant != null) {
                _useSampleImage('assets/images/disease_late_blight.webp');
              }
            },
          ),
        ),
      );
    }
  }

  void _useSampleImage(String assetPath) {
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => ScanPreviewScreen(
          plant: _targetPlant ?? _getDefaultPlant(),
          imagePath: assetPath,
          isAssetImage: true,
        ),
      ),
    );
  }

  PlantModel _getDefaultPlant() {
    final plants = context.read<PlantProvider>().allPlants;
    if (plants.isNotEmpty) return plants.first;
    return PlantModel(
      id: 'plant_default',
      name: 'Tomat Cherry Blok A',
      variety: 'Cherry Tropis',
      plantedDate: DateTime.now().subtract(const Duration(days: 63)),
      location: 'Greenhouse 1 • Rak B3',
      notes: 'Tanaman tomat utama.',
      imagePath: 'assets/images/hero_tomatoes.webp',
    );
  }

  void _showHelpSheet() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (ctx) {
        return SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(22),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Center(
                  child: Container(
                    width: 40,
                    height: 4,
                    decoration: BoxDecoration(
                      color: AppColors.divider,
                      borderRadius: BorderRadius.circular(2),
                    ),
                  ),
                ),
                const SizedBox(height: 16),
                const Text(
                  'Panduan Pemotretan Daun Tomat',
                  style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800),
                ),
                const SizedBox(height: 12),
                const Text(
                  '• Fokuskan kamera pada 1 helai daun yang memiliki gejala bercak.\n'
                  '• Pastikan daun mengisi minimal 60% area kotak panduan.\n'
                  '• Hindari bayangan gelap atau sinar matahari langsung yang terlalu silau.\n'
                  '• Pastikan daun tidak buram atau goyang saat memotret.',
                  style: TextStyle(fontSize: 13.5, color: AppColors.textSecondary, height: 1.5),
                ),
                const SizedBox(height: 20),
                SizedBox(
                  width: double.infinity,
                  height: 46,
                  child: ElevatedButton(
                    onPressed: () => Navigator.pop(ctx),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppColors.primaryGreen,
                      foregroundColor: Colors.white,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(AppSizes.radiusFull),
                      ),
                    ),
                    child: const Text('Mengerti', style: TextStyle(fontWeight: FontWeight.w700)),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        alignment: Alignment.center,
        children: [
          // Background Leaf Camera Texture
          Positioned.fill(
            child: Image.asset(
              'assets/images/disease_late_blight.webp',
              fit: BoxFit.cover,
            ),
          ),
          Positioned.fill(
            child: Container(
              color: Colors.black.withValues(alpha: 0.28),
            ),
          ),

          // Top Action Controls (Close, Flash, Switch Camera)
          Positioned(
            top: MediaQuery.of(context).padding.top + 12,
            left: 20,
            right: 20,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                // Close button (X)
                GestureDetector(
                  onTap: () => Navigator.pop(context),
                  child: Container(
                    width: 42,
                    height: 42,
                    decoration: BoxDecoration(
                      color: Colors.black.withValues(alpha: 0.45),
                      shape: BoxShape.circle,
                    ),
                    child: const Icon(Icons.close_rounded, color: Colors.white, size: 22),
                  ),
                ),

                // Flash and Switch Camera
                Row(
                  children: [
                    GestureDetector(
                      onTap: () {
                        setState(() {
                          _isFlashOn = !_isFlashOn;
                        });
                      },
                      child: Container(
                        width: 42,
                        height: 42,
                        margin: const EdgeInsets.only(right: 12),
                        decoration: BoxDecoration(
                          color: _isFlashOn
                              ? AppColors.warningOrange.withValues(alpha: 0.7)
                              : Colors.black.withValues(alpha: 0.45),
                          shape: BoxShape.circle,
                        ),
                        child: Icon(
                          _isFlashOn ? Icons.flash_on_rounded : Icons.flash_off_rounded,
                          color: Colors.white,
                          size: 20,
                        ),
                      ),
                    ),
                    GestureDetector(
                      onTap: () {
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(
                            content: Text('Beralih mode kamera'),
                            duration: Duration(milliseconds: 800),
                          ),
                        );
                      },
                      child: Container(
                        width: 42,
                        height: 42,
                        decoration: BoxDecoration(
                          color: Colors.black.withValues(alpha: 0.45),
                          shape: BoxShape.circle,
                        ),
                        child: const Icon(Icons.flip_camera_ios_outlined, color: Colors.white, size: 20),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),

          // Top Instruction Pill Banner & Plant Selector
          Positioned(
            top: MediaQuery.of(context).padding.top + 66,
            left: 20,
            right: 20,
            child: Column(
              children: [
                // Plant selector chip
                GestureDetector(
                  onTap: _showPlantPicker,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                    decoration: BoxDecoration(
                      color: Colors.black.withValues(alpha: 0.7),
                      borderRadius: BorderRadius.circular(AppSizes.radiusFull),
                      border: Border.all(color: Colors.white.withValues(alpha: 0.3)),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Icon(Icons.spa_outlined, color: Color(0xFF00E676), size: 14),
                        const SizedBox(width: 6),
                        Text(
                          _targetPlant?.name ?? 'Pilih Tanaman',
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 12,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                        const SizedBox(width: 4),
                        const Icon(Icons.keyboard_arrow_down_rounded, color: Colors.white, size: 16),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 8),

                // Guide text
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 7),
                  decoration: BoxDecoration(
                    color: Colors.black.withValues(alpha: 0.6),
                    borderRadius: BorderRadius.circular(AppSizes.radiusFull),
                  ),
                  child: const Text(
                    'Arahkan pada 1 helai daun bergejala',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
              ],
            ),
          ),

          // Central Framing Guide (Dashed Box with Neon Green Corners & Center Dot)
          Center(
            child: Stack(
              alignment: Alignment.center,
              children: [
                // Dashed outline frame
                Container(
                  width: 270,
                  height: 310,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(
                      color: Colors.white.withValues(alpha: 0.6),
                      width: 1.5,
                    ),
                  ),
                ),

                // 4 Neon Green Rounded Corner Accents
                _buildCorner(top: -2, left: -2, isTop: true, isLeft: true),
                _buildCorner(top: -2, right: -2, isTop: true, isLeft: false),
                _buildCorner(bottom: -2, left: -2, isTop: false, isLeft: true),
                _buildCorner(bottom: -2, right: -2, isTop: false, isLeft: false),

                // Center green targeting dot
                Container(
                  width: 8,
                  height: 8,
                  decoration: const BoxDecoration(
                    color: Color(0xFF00E676),
                    shape: BoxShape.circle,
                    boxShadow: [
                      BoxShadow(
                        color: Color(0xFF00E676),
                        blurRadius: 8,
                        spreadRadius: 2,
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),

          // Bottom Instruction Pill Banner: "💡 Pastikan daun fokus & pencahayaan cukup"
          Positioned(
            bottom: 120,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
              decoration: BoxDecoration(
                color: Colors.black.withValues(alpha: 0.6),
                borderRadius: BorderRadius.circular(AppSizes.radiusFull),
              ),
              child: const Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.lightbulb_outline_rounded, color: Colors.white, size: 16),
                  SizedBox(width: 8),
                  Text(
                    'Pastikan daun fokus & pencahayaan cukup',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 12,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ],
              ),
            ),
          ),

          // Bottom Action Controls (Gallery, Shutter Button, Help)
          Positioned(
            bottom: 34,
            left: 24,
            right: 24,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                // Gallery Icon Button
                GestureDetector(
                  onTap: () => _pickImage(ImageSource.gallery),
                  child: Container(
                    width: 52,
                    height: 52,
                    decoration: BoxDecoration(
                      color: Colors.black.withValues(alpha: 0.55),
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: Colors.white.withValues(alpha: 0.25)),
                    ),
                    child: const Icon(Icons.image_outlined, color: Colors.white, size: 24),
                  ),
                ),

                // Circular Shutter Button with Orange/Coral Gradient Ring
                GestureDetector(
                  onTap: () => _pickImage(ImageSource.camera),
                  child: Container(
                    width: 76,
                    height: 76,
                    padding: const EdgeInsets.all(4),
                    decoration: const BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: AppColors.orangeScannerGradient,
                      boxShadow: [
                        BoxShadow(
                          color: Color(0x50F95B3D),
                          blurRadius: 16,
                          offset: Offset(0, 4),
                        ),
                      ],
                    ),
                    child: Container(
                      decoration: const BoxDecoration(
                        color: Colors.white,
                        shape: BoxShape.circle,
                      ),
                      child: _isLoading
                          ? const Center(
                              child: SizedBox(
                                width: 24,
                                height: 24,
                                child: CircularProgressIndicator(
                                  color: AppColors.orangeAccent,
                                  strokeWidth: 2.5,
                                ),
                              ),
                            )
                          : null,
                    ),
                  ),
                ),

                // Help Button (?)
                GestureDetector(
                  onTap: _showHelpSheet,
                  child: Container(
                    width: 52,
                    height: 52,
                    decoration: BoxDecoration(
                      color: Colors.black.withValues(alpha: 0.55),
                      shape: BoxShape.circle,
                      border: Border.all(color: Colors.white.withValues(alpha: 0.25)),
                    ),
                    child: const Icon(Icons.question_mark_rounded, color: Colors.white, size: 22),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCorner({
    double? top,
    double? bottom,
    double? left,
    double? right,
    required bool isTop,
    required bool isLeft,
  }) {
    return Positioned(
      top: top,
      bottom: bottom,
      left: left,
      right: right,
      child: Container(
        width: 28,
        height: 28,
        decoration: BoxDecoration(
          border: Border(
            top: isTop ? const BorderSide(color: Color(0xFF00E676), width: 3.5) : BorderSide.none,
            bottom: !isTop ? const BorderSide(color: Color(0xFF00E676), width: 3.5) : BorderSide.none,
            left: isLeft ? const BorderSide(color: Color(0xFF00E676), width: 3.5) : BorderSide.none,
            right: !isLeft ? const BorderSide(color: Color(0xFF00E676), width: 3.5) : BorderSide.none,
          ),
          borderRadius: BorderRadius.only(
            topLeft: isTop && isLeft ? const Radius.circular(16) : Radius.zero,
            topRight: isTop && !isLeft ? const Radius.circular(16) : Radius.zero,
            bottomLeft: !isTop && isLeft ? const Radius.circular(16) : Radius.zero,
            bottomRight: !isTop && !isLeft ? const Radius.circular(16) : Radius.zero,
          ),
        ),
      ),
    );
  }
}
