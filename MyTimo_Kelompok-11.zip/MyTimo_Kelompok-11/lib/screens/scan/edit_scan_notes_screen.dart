import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../models/scan_record_model.dart';
import '../../providers/scan_provider.dart';
import '../../theme/app_colors.dart';
import '../../theme/app_sizes.dart';
import '../../widgets/status_badge.dart';

/// Halaman Ubah Catatan Riwayat sesuai Screenshot 3.3
class EditScanNotesScreen extends StatefulWidget {
  final ScanRecordModel scan;

  const EditScanNotesScreen({super.key, required this.scan});

  @override
  State<EditScanNotesScreen> createState() => _EditScanNotesScreenState();
}

class _EditScanNotesScreenState extends State<EditScanNotesScreen> {
  late final TextEditingController _controller;
  int _charCount = 0;
  static const int _maxChars = 500;

  @override
  void initState() {
    super.initState();
    _controller = TextEditingController(text: widget.scan.notes);
    _charCount = _controller.text.length;
    _controller.addListener(() {
      setState(() {
        _charCount = _controller.text.length;
      });
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _appendSuggestion(String text) {
    final current = _controller.text.trim();
    if (current.isEmpty) {
      _controller.text = text;
    } else {
      _controller.text = '$current. $text';
    }
    _controller.selection = TextSelection.fromPosition(
      TextPosition(offset: _controller.text.length),
    );
  }

  void _saveNotes() {
    context.read<ScanProvider>().updateScanNotes(
      widget.scan.id,
      _controller.text.trim(),
    );

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Catatan pemindaian berhasil disimpan'),
        backgroundColor: AppColors.primaryGreen,
      ),
    );

    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    final scan = widget.scan;

    return Scaffold(
      backgroundColor: const Color(0xFFF8FAF8),
      appBar: PreferredSize(
        preferredSize: const Size.fromHeight(60),
        child: Container(
          decoration: const BoxDecoration(
            gradient: AppColors.homeHeaderGradient,
          ),
          child: SafeArea(
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(
                  children: [
                    IconButton(
                      icon: const Icon(Icons.arrow_back_rounded, color: Colors.white),
                      onPressed: () => Navigator.pop(context),
                    ),
                    const Text(
                      'Ubah Catatan Riwayat',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 18,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ],
                ),
                IconButton(
                  icon: const Icon(Icons.close_rounded, color: Colors.white),
                  onPressed: () => Navigator.pop(context),
                ),
              ],
            ),
          ),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Top Summary Card
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: AppColors.border),
                boxShadow: const [
                  BoxShadow(
                    color: Color(0x06000000),
                    blurRadius: 8,
                    offset: Offset(0, 2),
                  ),
                ],
              ),
              child: Row(
                children: [
                  ClipRRect(
                    borderRadius: BorderRadius.circular(12),
                    child: SizedBox(
                      width: 52,
                      height: 52,
                      child: scan.isAssetImage
                          ? Image.asset(scan.imagePath, fit: BoxFit.cover)
                          : kIsWeb
                              ? Image.network(scan.imagePath, fit: BoxFit.cover)
                              : Image.file(File(scan.imagePath), fit: BoxFit.cover),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          scan.displayTitle,
                          style: const TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.w800,
                            color: AppColors.textPrimary,
                          ),
                        ),
                        const SizedBox(height: 2),
                        Text(
                          scan.plantName,
                          style: const TextStyle(
                            fontSize: 12,
                            color: AppColors.textSecondary,
                          ),
                        ),
                        const SizedBox(height: 2),
                        Row(
                          children: [
                            const Icon(Icons.access_time_rounded, size: 12, color: AppColors.textMuted),
                            const SizedBox(width: 4),
                            Text(
                              scan.formattedDateTime,
                              style: const TextStyle(fontSize: 11, color: AppColors.textMuted),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  StatusBadge(
                    status: scan.severity,
                    borderRadius: BorderRadius.circular(AppSizes.radiusFull),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),

            // Form Title: "Catatan Riwayat"
            const Text(
              'Catatan Riwayat',
              style: TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w700,
                color: AppColors.textPrimary,
              ),
            ),
            const SizedBox(height: 8),

            // Multiline Input Field
            TextField(
              controller: _controller,
              maxLines: 5,
              maxLength: _maxChars,
              buildCounter: (context, {required currentLength, required isFocused, maxLength}) => null,
              decoration: InputDecoration(
                hintText: 'Tuliskan catatan kondisi daun...',
                hintStyle: const TextStyle(color: AppColors.textMuted, fontSize: 13.5),
                contentPadding: const EdgeInsets.all(16),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(AppSizes.radiusL),
                  borderSide: const BorderSide(color: AppColors.inputBorderLight, width: 1.2),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(AppSizes.radiusL),
                  borderSide: const BorderSide(color: AppColors.primaryGreen, width: 1.5),
                ),
              ),
            ),
            const SizedBox(height: 6),

            // Character Counter: "Batas catatan observasi: 238 / 500 Karakter"
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text(
                  'Batas catatan observasi:',
                  style: TextStyle(fontSize: 11, color: AppColors.textMuted),
                ),
                Text(
                  '$_charCount / $_maxChars Karakter',
                  style: const TextStyle(
                    fontSize: 11.5,
                    fontWeight: FontWeight.w600,
                    color: AppColors.textSecondary,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 20),

            // Section: "Saran Tindakan Lapangan (Klik untuk sisipkan):"
            const Text(
              'Saran Tindakan Lapangan (Klik untuk sisipkan):',
              style: TextStyle(
                fontSize: 13,
                fontWeight: FontWeight.w700,
                color: AppColors.textSecondary,
              ),
            ),
            const SizedBox(height: 10),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                _buildQuickActionChip('+ Pemangkasan Daun', 'Dilakukan pemangkasan daun terdampak'),
                _buildQuickActionChip('+ Semprot Fungisida', 'Penyemprotan fungisida tembaga 2g/L'),
                _buildQuickActionChip('+ Evaluasi 3 Hari', 'Jadwal evaluasi ulang dalam 3 hari'),
                _buildQuickActionChip('+ Isolasi Blok', 'Isolasi bedengan untuk mencegah penyebaran'),
              ],
            ),
            const SizedBox(height: 32),

            // Submit Button: "✓ Simpan Perubahan Catatan"
            SizedBox(
              width: double.infinity,
              height: 50,
              child: ElevatedButton(
                onPressed: _saveNotes,
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppColors.primaryGreen,
                  foregroundColor: Colors.white,
                  elevation: 0,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(AppSizes.radiusFull),
                  ),
                ),
                child: const Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.check_rounded, size: 20),
                    SizedBox(width: 8),
                    Text(
                      'Simpan Perubahan Catatan',
                      style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 14),

            // Cancel Button: "Batalkan & kembali ke Detail"
            Center(
              child: TextButton(
                onPressed: () => Navigator.pop(context),
                child: const Text(
                  'Batalkan & kembali ke Detail',
                  style: TextStyle(
                    color: AppColors.textSecondary,
                    fontSize: 13.5,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ),
            const SizedBox(height: 24),
          ],
        ),
      ),
    );
  }

  Widget _buildQuickActionChip(String label, String appendText) {
    return GestureDetector(
      onTap: () => _appendSuggestion(appendText),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
        decoration: BoxDecoration(
          color: const Color(0xFFE8F5E9),
          borderRadius: BorderRadius.circular(AppSizes.radiusFull),
          border: Border.all(color: const Color(0xFFC8E6C9)),
        ),
        child: Text(
          label,
          style: const TextStyle(
            color: AppColors.primaryGreenDark,
            fontSize: 12,
            fontWeight: FontWeight.w700,
          ),
        ),
      ),
    );
  }
}
