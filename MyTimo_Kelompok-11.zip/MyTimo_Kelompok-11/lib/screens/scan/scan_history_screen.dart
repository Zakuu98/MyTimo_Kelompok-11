import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../models/scan_record_model.dart';
import '../../providers/plant_provider.dart';
import '../../providers/scan_provider.dart';
import '../../theme/app_colors.dart';
import '../../theme/app_sizes.dart';
import '../../widgets/status_badge.dart';
import 'scan_camera_screen.dart';
import 'scan_history_detail_screen.dart';

/// Halaman Riwayat Pemindaian sesuai Screenshot 2.2 & 3.1
class ScanHistoryScreen extends StatefulWidget {
  final String? filterPlantId;

  const ScanHistoryScreen({super.key, this.filterPlantId});

  @override
  State<ScanHistoryScreen> createState() => _ScanHistoryScreenState();
}

class _ScanHistoryScreenState extends State<ScanHistoryScreen> {
  final TextEditingController _searchController = TextEditingController();

  @override
  void initState() {
    super.initState();
    if (widget.filterPlantId != null) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        context.read<ScanProvider>().setFilterPlantId(widget.filterPlantId);
      });
    }
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  void _showFilterBottomSheet(BuildContext context) {
    final scanProvider = context.read<ScanProvider>();
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (ctx) {
        return StatefulBuilder(
          builder: (bottomSheetCtx, setSheetState) {
            final currentStatus = scanProvider.statusFilter;
            final currentTime = scanProvider.timeRangeFilter;

            return SafeArea(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Center(
                      child: Container(
                        width: 40,
                        height: 4,
                        decoration: BoxDecoration(
                          color: AppColors.divider,
                          borderRadius: BorderRadius.circular(2),
                        ),
                      ),
                    ),
                    const SizedBox(height: 16),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text(
                          'Filter Riwayat',
                          style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800),
                        ),
                        TextButton(
                          onPressed: () {
                            scanProvider.resetFilters();
                            _searchController.clear();
                            Navigator.pop(ctx);
                          },
                          child: const Text('Reset', style: TextStyle(color: AppColors.primaryGreen, fontWeight: FontWeight.w700)),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    const Text('Status Tingkat Keparahan', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 13)),
                    const SizedBox(height: 8),
                    Wrap(
                      spacing: 8,
                      children: ['Semua Status', 'Sedang', 'Sehat', 'Parah'].map((status) {
                        final isSelected = currentStatus == status;
                        return ChoiceChip(
                          label: Text(status),
                          selected: isSelected,
                          selectedColor: AppColors.primaryGreen,
                          labelStyle: TextStyle(
                            color: isSelected ? Colors.white : AppColors.textPrimary,
                            fontWeight: isSelected ? FontWeight.w700 : FontWeight.w500,
                            fontSize: 12.5,
                          ),
                          onSelected: (val) {
                            if (val) {
                              scanProvider.setStatusFilter(status);
                              setSheetState(() {});
                            }
                          },
                        );
                      }).toList(),
                    ),
                    const SizedBox(height: 16),
                    const Text('Rentang Waktu', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 13)),
                    const SizedBox(height: 8),
                    Wrap(
                      spacing: 8,
                      children: ['Semua Waktu', 'Hari Ini', 'Minggu Ini', 'Bulan Ini'].map((time) {
                        final isSelected = currentTime == time;
                        return ChoiceChip(
                          label: Text(time),
                          selected: isSelected,
                          selectedColor: AppColors.primaryGreen,
                          labelStyle: TextStyle(
                            color: isSelected ? Colors.white : AppColors.textPrimary,
                            fontWeight: isSelected ? FontWeight.w700 : FontWeight.w500,
                            fontSize: 12.5,
                          ),
                          onSelected: (val) {
                            if (val) {
                              scanProvider.setTimeRangeFilter(time);
                              setSheetState(() {});
                            }
                          },
                        );
                      }).toList(),
                    ),
                    const SizedBox(height: 24),
                    SizedBox(
                      width: double.infinity,
                      height: 48,
                      child: ElevatedButton(
                        onPressed: () => Navigator.pop(ctx),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: AppColors.primaryGreen,
                          foregroundColor: Colors.white,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(AppSizes.radiusFull),
                          ),
                        ),
                        child: const Text('Terapkan Filter', style: TextStyle(fontWeight: FontWeight.w700)),
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final scanProvider = context.watch<ScanProvider>();
    final scans = scanProvider.filteredScans;
    final isFilterActive = scanProvider.isFilterActive;

    return Scaffold(
      backgroundColor: const Color(0xFFF8FAF8),
      body: Column(
        children: [
          // Header Section with Green Gradient
          Container(
            width: double.infinity,
            padding: EdgeInsets.only(
              top: MediaQuery.of(context).padding.top + 12,
              left: 20,
              right: 20,
              bottom: 18,
            ),
            decoration: const BoxDecoration(
              gradient: AppColors.primaryGreenGradient,
            ),
            child: Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      children: [
                        GestureDetector(
                          onTap: () {
                            if (widget.filterPlantId != null) {
                              scanProvider.setFilterPlantId(null);
                            }
                            if (Navigator.canPop(context)) {
                              Navigator.pop(context);
                            }
                          },
                          child: const Padding(
                            padding: EdgeInsets.only(right: 12),
                            child: Icon(Icons.arrow_back_rounded, color: Colors.white, size: 22),
                          ),
                        ),
                        const Text(
                          'Riwayat Pemindaian',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 19,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                      ],
                    ),
                    // Filter Action Button
                    GestureDetector(
                      onTap: () => _showFilterBottomSheet(context),
                      child: Container(
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: isFilterActive ? const Color(0xFF00A86B) : Colors.transparent,
                          borderRadius: BorderRadius.circular(10),
                          border: isFilterActive
                              ? Border.all(color: Colors.white.withValues(alpha: 0.8), width: 1.5)
                              : null,
                        ),
                        child: const Icon(
                          Icons.filter_alt_outlined,
                          color: Colors.white,
                          size: 22,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 14),

                // Search Bar
                Container(
                  height: 46,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(AppSizes.radiusFull),
                    boxShadow: const [
                      BoxShadow(
                        color: Color(0x10000000),
                        blurRadius: 8,
                        offset: Offset(0, 3),
                      ),
                    ],
                  ),
                  child: TextField(
                    controller: _searchController,
                    onChanged: (val) => scanProvider.setSearchQuery(val),
                    decoration: InputDecoration(
                      hintText: 'Cari tanggal, tanaman, atau penyakit...',
                      hintStyle: const TextStyle(color: AppColors.textMuted, fontSize: 13.5),
                      prefixIcon: const Icon(Icons.search_rounded, color: AppColors.textMuted, size: 22),
                      suffixIcon: _searchController.text.isNotEmpty
                          ? IconButton(
                              icon: const Icon(Icons.close_rounded, size: 18, color: AppColors.textMuted),
                              onPressed: () {
                                _searchController.clear();
                                scanProvider.setSearchQuery('');
                              },
                            )
                          : null,
                      border: InputBorder.none,
                      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                    ),
                  ),
                ),
              ],
            ),
          ),

          // Filter Controls: Filter Tags or Disease Category Pills
          if (isFilterActive)
            _buildActiveFilterTags(scanProvider, scans.length)
          else
            _buildDiseaseFilterChips(scanProvider),

          // Main Body: List, Empty Search Results, or Empty History
          Expanded(
            child: scans.isEmpty
                ? (scanProvider.isFilterActive
                    ? _buildNoSearchResults(context, scanProvider)
                    : _buildEmptyState(context))
                : ListView.separated(
                    padding: const EdgeInsets.fromLTRB(16, 8, 16, 96),
                    itemCount: scans.length,
                    separatorBuilder: (context, index) => const SizedBox(height: 12),
                    itemBuilder: (context, index) {
                      final scan = scans[index];
                      return _buildScanCard(context, scan);
                    },
                  ),
          ),
        ],
      ),
    );
  }

  /// Pills Filter Berdasarkan Penyakit (Screenshot 2.2)
  Widget _buildDiseaseFilterChips(ScanProvider scanProvider) {
    return Container(
      height: 48,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
      child: ListView(
        scrollDirection: Axis.horizontal,
        children: [
          _buildFilterChip(
            label: 'Semua (${scanProvider.totalCount})',
            isSelected: scanProvider.diseaseFilter == 'Semua',
            onTap: () => scanProvider.setDiseaseFilter('Semua'),
          ),
          const SizedBox(width: 8),
          _buildFilterChip(
            label: 'Early Blight (${scanProvider.earlyBlightCount})',
            isSelected: scanProvider.diseaseFilter == 'Early Blight',
            onTap: () => scanProvider.setDiseaseFilter(
              scanProvider.diseaseFilter == 'Early Blight' ? 'Semua' : 'Early Blight',
            ),
          ),
          const SizedBox(width: 8),
          _buildFilterChip(
            label: 'Late Blight (${scanProvider.lateBlightCount})',
            isSelected: scanProvider.diseaseFilter == 'Late Blight',
            onTap: () => scanProvider.setDiseaseFilter(
              scanProvider.diseaseFilter == 'Late Blight' ? 'Semua' : 'Late Blight',
            ),
          ),
          const SizedBox(width: 8),
          _buildFilterChip(
            label: 'Daun Sehat (${scanProvider.healthyCount})',
            isSelected: scanProvider.diseaseFilter == 'Daun Sehat',
            onTap: () => scanProvider.setDiseaseFilter(
              scanProvider.diseaseFilter == 'Daun Sehat' ? 'Semua' : 'Daun Sehat',
            ),
          ),
        ],
      ),
    );
  }

  /// Baris Tag Filter Aktif (Screenshot 3.1)
  Widget _buildActiveFilterTags(ScanProvider scanProvider, int resultCount) {
    return Container(
      padding: const EdgeInsets.fromLTRB(16, 10, 16, 6),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              children: [
                if (scanProvider.searchQuery.isNotEmpty) ...[
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                    decoration: BoxDecoration(
                      color: const Color(0xFF1B5E20),
                      borderRadius: BorderRadius.circular(AppSizes.radiusFull),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(
                          '"${scanProvider.searchQuery}"',
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 12.5,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                        const SizedBox(width: 6),
                        GestureDetector(
                          onTap: () {
                            _searchController.clear();
                            scanProvider.setSearchQuery('');
                          },
                          child: const Icon(Icons.close_rounded, size: 16, color: Colors.white),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(width: 8),
                ],

                // Dropdown Tag Status
                GestureDetector(
                  onTap: () => _showFilterBottomSheet(context),
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      border: Border.all(
                        color: scanProvider.statusFilter != 'Semua Status'
                            ? AppColors.primaryGreen
                            : AppColors.border,
                      ),
                      borderRadius: BorderRadius.circular(AppSizes.radiusFull),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(
                          scanProvider.statusFilter,
                          style: TextStyle(
                            color: scanProvider.statusFilter != 'Semua Status'
                                ? AppColors.primaryGreenDark
                                : AppColors.textPrimary,
                            fontSize: 12.5,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        const SizedBox(width: 4),
                        const Icon(Icons.keyboard_arrow_down_rounded, size: 16, color: AppColors.textSecondary),
                      ],
                    ),
                  ),
                ),
                const SizedBox(width: 8),

                // Dropdown Tag Waktu
                GestureDetector(
                  onTap: () => _showFilterBottomSheet(context),
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      border: Border.all(
                        color: scanProvider.timeRangeFilter != 'Semua Waktu'
                            ? AppColors.primaryGreen
                            : AppColors.border,
                      ),
                      borderRadius: BorderRadius.circular(AppSizes.radiusFull),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(
                          scanProvider.timeRangeFilter,
                          style: TextStyle(
                            color: scanProvider.timeRangeFilter != 'Semua Waktu'
                                ? AppColors.primaryGreenDark
                                : AppColors.textPrimary,
                            fontSize: 12.5,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        const SizedBox(width: 4),
                        const Icon(Icons.keyboard_arrow_down_rounded, size: 16, color: AppColors.textSecondary),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'Menampilkan $resultCount riwayat pemindaian',
            style: const TextStyle(
              fontSize: 12,
              color: AppColors.textSecondary,
              fontWeight: FontWeight.w500,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildFilterChip({
    required String label,
    required bool isSelected,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
        decoration: BoxDecoration(
          color: isSelected ? AppColors.primaryGreen : Colors.white,
          borderRadius: BorderRadius.circular(AppSizes.radiusFull),
          border: Border.all(
            color: isSelected ? AppColors.primaryGreen : AppColors.border,
            width: 1,
          ),
        ),
        child: Center(
          child: Text(
            label,
            style: TextStyle(
              color: isSelected ? Colors.white : AppColors.textSecondary,
              fontWeight: isSelected ? FontWeight.w700 : FontWeight.w500,
              fontSize: 12.5,
            ),
          ),
        ),
      ),
    );
  }

  /// Card Item Riwayat Pemindaian 
  Widget _buildScanCard(BuildContext context, ScanRecordModel scan) {
    return GestureDetector(
      onTap: () {
        Navigator.of(context).push(
          MaterialPageRoute(
            builder: (_) => ScanHistoryDetailScreen(scanId: scan.id),
          ),
        );
      },
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: AppColors.border),
          boxShadow: const [
            BoxShadow(
              color: Color(0x06000000),
              blurRadius: 8,
              offset: Offset(0, 2),
            ),
          ],
        ),
        child: Row(
          children: [
            // Thumbnail Image
            ClipRRect(
              borderRadius: BorderRadius.circular(14),
              child: SizedBox(
                width: 62,
                height: 62,
                child: scan.isAssetImage
                    ? Image.asset(scan.imagePath, fit: BoxFit.cover)
                    : kIsWeb
                        ? Image.network(scan.imagePath, fit: BoxFit.cover)
                        : Image.file(File(scan.imagePath), fit: BoxFit.cover),
              ),
            ),
            const SizedBox(width: 12),

            // Scan Info
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    scan.displayTitle,
                    style: const TextStyle(
                      fontSize: 14.5,
                      fontWeight: FontWeight.w800,
                      color: AppColors.textPrimary,
                    ),
                  ),
                  const SizedBox(height: 3),
                  Text(
                    scan.plantName,
                    style: const TextStyle(
                      fontSize: 12.5,
                      color: AppColors.textSecondary,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  const SizedBox(height: 5),
                  Row(
                    children: [
                      const Icon(Icons.access_time_rounded, size: 13, color: AppColors.textMuted),
                      const SizedBox(width: 4),
                      Text(
                        scan.formattedDateTime,
                        style: const TextStyle(
                          fontSize: 11.5,
                          color: AppColors.textMuted,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),

            // Severity Badge (Refactored using reusable StatusBadge)
            StatusBadge(
              status: scan.severity,
              borderRadius: BorderRadius.circular(10),
            ),
          ],
        ),
      ),
    );
  }

  /// Tampilan Kosong Saat Hasil Filter / Pencarian Tidak Ditemukan (Screenshot 3.1)
  Widget _buildNoSearchResults(BuildContext context, ScanProvider scanProvider) {
    final queryText = scanProvider.searchQuery.isNotEmpty
        ? '"${scanProvider.searchQuery}"'
        : 'filter pencarian yang dipilih';

    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 88),
      child: Column(
        children: [
          // White Card "Riwayat Tidak Ditemukan"
          Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 32),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(22),
              border: Border.all(color: AppColors.border),
              boxShadow: const [
                BoxShadow(
                  color: Color(0x06000000),
                  blurRadius: 10,
                  offset: Offset(0, 3),
                ),
              ],
            ),
            child: Column(
              children: [
                // Document Icon with Magnifier & Question Mark
                Container(
                  width: 72,
                  height: 72,
                  decoration: BoxDecoration(
                    color: const Color(0xFFF1F8F1),
                    shape: BoxShape.circle,
                    border: Border.all(color: const Color(0xFFC8E6C9), width: 1.5),
                  ),
                  child: const Center(
                    child: Stack(
                      alignment: Alignment.center,
                      children: [
                        Icon(Icons.description_outlined, color: AppColors.primaryGreen, size: 36),
                        Positioned(
                          right: 0,
                          bottom: 0,
                          child: Icon(Icons.help_rounded, color: AppColors.orangeAccent, size: 18),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 18),
                const Text(
                  'Riwayat Tidak Ditemukan',
                  style: TextStyle(
                    fontSize: 17,
                    fontWeight: FontWeight.w800,
                    color: AppColors.textPrimary,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  'Tidak ada hasil scan dengan kata kunci $queryText. Coba periksa ejaan atau ubah filter pencarian Anda.',
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    fontSize: 13,
                    color: AppColors.textSecondary,
                    height: 1.45,
                  ),
                ),
                const SizedBox(height: 20),
                SizedBox(
                  height: 42,
                  child: OutlinedButton(
                    onPressed: () {
                      scanProvider.resetFilters();
                      _searchController.clear();
                    },
                    style: OutlinedButton.styleFrom(
                      side: const BorderSide(color: AppColors.primaryGreen, width: 1.5),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(AppSizes.radiusFull),
                      ),
                      padding: const EdgeInsets.symmetric(horizontal: 24),
                    ),
                    child: const Text(
                      'Reset Filter',
                      style: TextStyle(
                        color: AppColors.primaryGreen,
                        fontWeight: FontWeight.w700,
                        fontSize: 13.5,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 18),

          // Tips Pencarian Riwayat Box
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: AppColors.border),
            ),
            child: const Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Icon(Icons.lightbulb_outline_rounded, size: 18, color: Color(0xFFE65100)),
                    SizedBox(width: 8),
                    Text(
                      'Tips Pencarian Riwayat:',
                      style: TextStyle(
                        fontSize: 13.5,
                        fontWeight: FontWeight.w700,
                        color: AppColors.textPrimary,
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 10),
                Text(
                  '• Coba gunakan nama blok kebun seperti "Blok A" atau "Bedeng 01".',
                  style: TextStyle(fontSize: 12.5, color: AppColors.textSecondary, height: 1.4),
                ),
                SizedBox(height: 6),
                Text(
                  '• Cari berdasarkan nama penyakit seperti "Early Blight".',
                  style: TextStyle(fontSize: 12.5, color: AppColors.textSecondary, height: 1.4),
                ),
                SizedBox(height: 6),
                Text(
                  '• Atur rentang tanggal menjadi "Semua Waktu" untuk melihat riwayat.',
                  style: TextStyle(fontSize: 12.5, color: AppColors.textSecondary, height: 1.4),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  /// Tampilan Kosong Total (Belum Pernah Scan)
  Widget _buildEmptyState(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 80,
              height: 80,
              decoration: const BoxDecoration(
                color: Color(0xFFF1F8F1),
                shape: BoxShape.circle,
              ),
              child: const Icon(
                Icons.qr_code_scanner_rounded,
                size: 40,
                color: AppColors.primaryGreen,
              ),
            ),
            const SizedBox(height: 18),
            const Text(
              'Belum Ada Riwayat Pemindaian',
              style: TextStyle(
                fontSize: 17,
                fontWeight: FontWeight.w800,
                color: AppColors.textPrimary,
              ),
            ),
            const SizedBox(height: 8),
            const Text(
              'Ambil foto daun tanaman tomat Anda untuk mendeteksi gejala penyakit sedini mungkin.',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 13, color: AppColors.textSecondary, height: 1.4),
            ),
            const SizedBox(height: 24),
            ElevatedButton.icon(
              onPressed: () {
                final plants = context.read<PlantProvider>().allPlants;
                Navigator.of(context).push(
                  MaterialPageRoute(
                    builder: (_) => ScanCameraScreen(
                      selectedPlant: plants.isNotEmpty ? plants.first : null,
                    ),
                  ),
                );
              },
              icon: const Icon(Icons.camera_alt_outlined, size: 18),
              label: const Text('Mulai Pemindaian Sekarang'),
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.primaryGreen,
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(AppSizes.radiusFull),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
