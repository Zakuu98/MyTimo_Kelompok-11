import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../models/plant_model.dart';
import '../../providers/plant_provider.dart';
import '../../theme/app_colors.dart';
import '../../theme/app_sizes.dart';
import '../../utils/form_validators.dart';

/// Halaman Tambah & Ubah Tanaman sesuai Screenshot 3.3 dan 3.4
class AddEditPlantScreen extends StatefulWidget {
  final PlantModel? plantToEdit;

  const AddEditPlantScreen({super.key, this.plantToEdit});

  @override
  State<AddEditPlantScreen> createState() => _AddEditPlantScreenState();
}

class _AddEditPlantScreenState extends State<AddEditPlantScreen> {
  final _formKey = GlobalKey<FormState>();
  late final TextEditingController _nameController;
  late final TextEditingController _varietyController;
  late final TextEditingController _dateController;
  late final TextEditingController _locationController;
  late final TextEditingController _notesController;
  AutovalidateMode _autovalidateMode = AutovalidateMode.disabled;

  late DateTime _selectedDate;
  bool get isEditing => widget.plantToEdit != null;

  @override
  void initState() {
    super.initState();
    final p = widget.plantToEdit;
    _selectedDate = p?.plantedDate ?? DateTime.now();
    _nameController = TextEditingController(text: p?.name ?? '');
    _varietyController = TextEditingController(text: p?.variety ?? '');
    _dateController = TextEditingController(text: _formatDateDisplay(_selectedDate));
    _locationController = TextEditingController(text: p?.location ?? '');
    _notesController = TextEditingController(text: p?.notes ?? '');
  }

  @override
  void dispose() {
    _nameController.dispose();
    _varietyController.dispose();
    _dateController.dispose();
    _locationController.dispose();
    _notesController.dispose();
    super.dispose();
  }

  String _formatDateDisplay(DateTime dt) {
    const months = [
      'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni',
      'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'
    ];
    final day = dt.day.toString().padLeft(2, '0');
    final month = months[dt.month - 1];
    final year = dt.year;
    return '$day $month $year';
  }

  Future<void> _pickDate() async {
    final picked = await showDatePicker(
      context: context,
      initialDate: _selectedDate,
      firstDate: DateTime(2020),
      lastDate: DateTime.now().add(const Duration(days: 365)),
      builder: (context, child) {
        return Theme(
          data: Theme.of(context).copyWith(
            colorScheme: const ColorScheme.light(
              primary: AppColors.primaryGreen,
              onPrimary: Colors.white,
              onSurface: AppColors.textPrimary,
            ),
          ),
          child: child!,
        );
      },
    );

    if (picked != null) {
      setState(() {
        _selectedDate = picked;
        _dateController.text = _formatDateDisplay(picked);
      });
    }
  }

  void _savePlant() {
    setState(() {
      _autovalidateMode = AutovalidateMode.onUserInteraction;
    });

    if (!_formKey.currentState!.validate()) return;

    final name = _nameController.text.trim();
    final variety = _varietyController.text.trim().isEmpty ? 'Tomat Lokal' : _varietyController.text.trim();
    final location = _locationController.text.trim();
    final notes = _notesController.text.trim();

    final plantProvider = context.read<PlantProvider>();

    if (isEditing) {
      final updated = widget.plantToEdit!.copyWith(
        name: name,
        variety: variety,
        plantedDate: _selectedDate,
        location: location,
        notes: notes,
      );
      plantProvider.updatePlant(updated);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Data tanaman "$name" berhasil diperbarui'),
          backgroundColor: AppColors.primaryGreen,
        ),
      );
    } else {
      final newPlant = PlantModel(
        id: 'plant_${DateTime.now().millisecondsSinceEpoch}',
        name: name,
        variety: variety,
        plantedDate: _selectedDate,
        location: location,
        notes: notes,
        status: 'Belum Ada Data',
        diseaseTag: null,
        healthScore: null,
        imagePath: '',
        isAssetImage: false,
      );
      plantProvider.addPlant(newPlant);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Tanaman "$name" berhasil ditambahkan'),
          backgroundColor: AppColors.primaryGreen,
        ),
      );
    }

    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    final title = isEditing ? 'Ubah Tanaman' : 'Tambah Tanaman';
    final buttonText = isEditing ? '✓ Perbarui Data Tanaman' : '✓ Simpan Data Tanaman';

    return Scaffold(
      backgroundColor: AppColors.surface,
      appBar: PreferredSize(
        preferredSize: const Size.fromHeight(60),
        child: Container(
          decoration: const BoxDecoration(
            gradient: AppColors.homeHeaderGradient,
          ),
          child: SafeArea(
            child: Row(
              children: [
                IconButton(
                  icon: const Icon(Icons.arrow_back_rounded, color: Colors.white),
                  onPressed: () => Navigator.pop(context),
                ),
                Text(
                  title,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 18,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 20),
        child: Form(
          key: _formKey,
          autovalidateMode: _autovalidateMode,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Field 1: Nama Tanaman / Blok *
              const Text(
                'Nama Tanaman / Blok *',
                style: TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: AppColors.textPrimary),
              ),
              const SizedBox(height: 8),
              TextFormField(
                controller: _nameController,
                validator: FormValidators.validatePlantName,
                decoration: _buildInputDecoration(
                  hintText: 'Tomat Sayur Blok C',
                  prefixIcon: Icons.spa_outlined,
                ),
              ),
              const SizedBox(height: 18),

              // Field 2: Varietas / Jenis (Opsional)
              const Text(
                'Varietas / Jenis (Opsional)',
                style: TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: AppColors.textPrimary),
              ),
              const SizedBox(height: 8),
              TextFormField(
                controller: _varietyController,
                validator: FormValidators.validatePlantVariety,
                decoration: _buildInputDecoration(
                  hintText: 'Gustavi F1',
                  prefixIcon: Icons.eco_outlined,
                ),
              ),
              const SizedBox(height: 18),

              // Field 3: Tanggal Tanam *
              const Text(
                'Tanggal Tanam *',
                style: TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: AppColors.textPrimary),
              ),
              const SizedBox(height: 8),
              TextFormField(
                controller: _dateController,
                readOnly: true,
                onTap: _pickDate,
                decoration: _buildInputDecoration(
                  hintText: '15 September 2026',
                  prefixIcon: Icons.calendar_today_outlined,
                ),
              ),
              const SizedBox(height: 18),

              // Field 4: Lokasi / Keterangan *
              const Text(
                'Lokasi / Keterangan *',
                style: TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: AppColors.textPrimary),
              ),
              const SizedBox(height: 8),
              TextFormField(
                controller: _locationController,
                validator: FormValidators.validatePlantLocation,
                decoration: _buildInputDecoration(
                  hintText: 'Lahan Timur - Bedeng 02',
                  prefixIcon: Icons.location_on_outlined,
                ),
              ),
              const SizedBox(height: 18),

              // Field 5: Catatan Awal / Catatan Pemulihan
              Text(
                isEditing ? 'Catatan Pemulihan' : 'Catatan Awal',
                style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: AppColors.textPrimary),
              ),
              const SizedBox(height: 8),
              TextFormField(
                controller: _notesController,
                maxLines: 3,
                decoration: InputDecoration(
                  hintText: isEditing
                      ? 'Daun bawah mulai membaik pasca pemangkasan.'
                      : 'Bibit semai 25 hari, media tanah kompos organik.',
                  hintStyle: const TextStyle(color: AppColors.textMuted, fontSize: 13.5),
                  contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(AppSizes.radiusL),
                    borderSide: const BorderSide(color: AppColors.inputBorderLight, width: 1.2),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(AppSizes.radiusL),
                    borderSide: const BorderSide(color: AppColors.primaryGreen, width: 1.5),
                  ),
                ),
              ),
              const SizedBox(height: 16),

              // Database Note Info
              Row(
                children: [
                  const Icon(Icons.storage_rounded, size: 16, color: AppColors.textMuted),
                  const SizedBox(width: 6),
                  Expanded(
                    child: Text(
                      'Data tersimpan pada memori aplikasi lokal MyTimo.',
                      style: TextStyle(fontSize: 12, color: AppColors.textSecondary.withValues(alpha: 0.9)),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 28),

              // Submit Button
              SizedBox(
                width: double.infinity,
                height: 52,
                child: ElevatedButton(
                  onPressed: _savePlant,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppColors.primaryGreen,
                    foregroundColor: Colors.white,
                    elevation: 0,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(AppSizes.radiusFull),
                    ),
                  ),
                  child: Text(
                    buttonText,
                    style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700),
                  ),
                ),
              ),
              const SizedBox(height: 32),
            ],
          ),
        ),
      ),
    );
  }

  InputDecoration _buildInputDecoration({
    required String hintText,
    required IconData prefixIcon,
  }) {
    return InputDecoration(
      hintText: hintText,
      hintStyle: const TextStyle(color: AppColors.textMuted, fontSize: 14),
      prefixIcon: Icon(prefixIcon, color: AppColors.textMuted, size: 20),
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(AppSizes.radiusL),
        borderSide: const BorderSide(color: AppColors.inputBorderLight, width: 1.2),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(AppSizes.radiusL),
        borderSide: const BorderSide(color: AppColors.primaryGreen, width: 1.5),
      ),
      errorBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(AppSizes.radiusL),
        borderSide: const BorderSide(color: AppColors.tomatoRed, width: 1.2),
      ),
      focusedErrorBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(AppSizes.radiusL),
        borderSide: const BorderSide(color: AppColors.tomatoRed, width: 1.5),
      ),
    );
  }
}
