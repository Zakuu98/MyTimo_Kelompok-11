import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../../models/plant_model.dart';
import '../../../providers/plant_provider.dart';
import '../../../providers/scan_provider.dart';
import '../../../theme/app_colors.dart';
import '../../../theme/app_sizes.dart';

/// Dialog konfirmasi penghapusan data tanaman
/// Hasil refactoring Temuan Audit 2 (Ekstraksi dialog monolitik dari PlantDetailScreen).
class PlantDeleteDialog extends StatelessWidget {
  final PlantModel plant;
  final VoidCallback onDeleted;

  const PlantDeleteDialog({
    super.key,
    required this.plant,
    required this.onDeleted,
  });

  /// Helper statis untuk menampilkan dialog secara deklaratif
  static Future<void> show(BuildContext context, PlantModel plant) {
    return showDialog(
      context: context,
      barrierDismissible: true,
      builder: (dialogCtx) => PlantDeleteDialog(
        plant: plant,
        onDeleted: () {
          // Hapus relasi riwayat scan & data tanaman
          dialogCtx.read<ScanProvider>().deleteScansByPlantId(plant.id);
          dialogCtx.read<PlantProvider>().deletePlant(plant.id);

          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('Tanaman "${plant.name}" berhasil dihapus'),
              backgroundColor: AppColors.tomatoRed,
            ),
          );
          Navigator.pop(context);
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: Colors.transparent,
      insetPadding: const EdgeInsets.symmetric(horizontal: 24),
      child: Stack(
        clipBehavior: Clip.none,
        alignment: Alignment.topCenter,
        children: [
          // White Dialog Card
          Container(
            margin: const EdgeInsets.only(top: 36),
            padding: const EdgeInsets.fromLTRB(20, 48, 20, 24),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(28),
              boxShadow: const [
                BoxShadow(
                  color: Color(0x20000000),
                  blurRadius: 20,
                  offset: Offset(0, 8),
                ),
              ],
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Text(
                  'Hapus Data Tanaman?',
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.w800,
                    color: AppColors.textPrimary,
                  ),
                ),
                const SizedBox(height: 8),
                const Text(
                  'Apakah anda yakin ingin menghapus data tanaman ini',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 13.5,
                    color: AppColors.textSecondary,
                  ),
                ),
                const SizedBox(height: 16),

                // Plant Highlight Card
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 16),
                  decoration: BoxDecoration(
                    color: const Color(0xFFF8FAF8),
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: AppColors.border),
                  ),
                  child: Text(
                    plant.name,
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w800,
                      color: AppColors.textPrimary,
                    ),
                  ),
                ),
                const SizedBox(height: 16),

                // Warning Alert
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: const Color(0xFFFFF3E0),
                    borderRadius: BorderRadius.circular(14),
                  ),
                  child: const Column(
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.warning_amber_rounded, color: AppColors.tomatoRed, size: 18),
                          SizedBox(width: 6),
                          Text(
                            'Peringatan!',
                            style: TextStyle(
                              color: AppColors.tomatoRed,
                              fontSize: 13,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ],
                      ),
                      SizedBox(height: 4),
                      Text(
                        'Seluruh riwayat scan dan rencana penanganan terkait akan dihapus permanen dari lokal.',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: Color(0xFFB71C1C),
                          fontSize: 11.5,
                          height: 1.35,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 24),

                // Action Buttons
                Row(
                  children: [
                    Expanded(
                      child: SizedBox(
                        height: 46,
                        child: OutlinedButton(
                          onPressed: () => Navigator.pop(context),
                          style: OutlinedButton.styleFrom(
                            side: const BorderSide(color: AppColors.border),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(AppSizes.radiusFull),
                            ),
                          ),
                          child: const Text(
                            'Batal',
                            style: TextStyle(
                              color: AppColors.textPrimary,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: SizedBox(
                        height: 46,
                        child: ElevatedButton(
                          onPressed: () {
                            Navigator.pop(context); // Tutup dialog
                            onDeleted(); // Panggil callback penghapusan & navigasi
                          },
                          style: ElevatedButton.styleFrom(
                            backgroundColor: AppColors.orangeDeep,
                            foregroundColor: Colors.white,
                            elevation: 0,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(AppSizes.radiusFull),
                            ),
                          ),
                          child: const Text(
                            'Ya, Hapus',
                            style: TextStyle(
                              fontSize: 14,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),

          // Floating Trash Icon Badge
          Positioned(
            top: 0,
            child: Container(
              width: 72,
              height: 72,
              decoration: BoxDecoration(
                gradient: AppColors.orangeScannerGradient,
                shape: BoxShape.circle,
                border: Border.all(color: Colors.white, width: 4),
                boxShadow: const [
                  BoxShadow(
                    color: Color(0x25E84118),
                    blurRadius: 14,
                    offset: Offset(0, 6),
                  ),
                ],
              ),
              child: const Icon(
                Icons.delete_outline_rounded,
                color: Colors.white,
                size: 34,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
