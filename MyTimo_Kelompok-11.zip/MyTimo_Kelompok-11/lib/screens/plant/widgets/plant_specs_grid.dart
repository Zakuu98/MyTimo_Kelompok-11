import 'package:flutter/material.dart';
import '../../../models/plant_model.dart';
import '../../../theme/app_colors.dart';

/// Widget Grid 2x2 Spesifikasi Tanaman (Lokasi, Tanggal Ditanam, Varietas, Skor Sehat)
/// Hasil refactoring Temuan Audit 2 (Modularisasi komponen tampilan PlantDetailScreen).
class PlantSpecsGrid extends StatelessWidget {
  final PlantModel plant;
  final String healthScoreDisplay;

  const PlantSpecsGrid({
    super.key,
    required this.plant,
    required this.healthScoreDisplay,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Row(
          children: [
            Expanded(
              child: _buildSpecCard(
                icon: Icons.location_on_outlined,
                label: 'Lokasi',
                value: plant.location,
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: _buildSpecCard(
                icon: Icons.calendar_today_outlined,
                label: 'Ditanam',
                value: plant.formattedPlantedDateShort,
              ),
            ),
          ],
        ),
        const SizedBox(height: 12),
        Row(
          children: [
            Expanded(
              child: _buildSpecCard(
                icon: Icons.eco_outlined,
                label: 'Varietas',
                value: plant.variety,
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: _buildSpecCard(
                icon: Icons.show_chart_rounded,
                label: 'Skor Sehat',
                value: healthScoreDisplay,
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildSpecCard({
    required IconData icon,
    required String label,
    required String value,
  }) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: const Color(0xFFF9FBF9),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.border),
      ),
      child: Row(
        children: [
          Container(
            width: 38,
            height: 38,
            decoration: BoxDecoration(
              color: AppColors.greenBadgeBackground,
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(icon, color: AppColors.primaryGreen, size: 20),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: const TextStyle(
                    fontSize: 11,
                    color: AppColors.textSecondary,
                    fontWeight: FontWeight.w500,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  value,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    fontSize: value.length > 15 ? 11.5 : 13,
                    fontWeight: FontWeight.w700,
                    color: AppColors.textPrimary,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
