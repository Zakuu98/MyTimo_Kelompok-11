import 'package:flutter/material.dart';
import '../../../models/plant_model.dart';
import '../../../models/scan_record_model.dart';
import '../../../theme/app_colors.dart';

/// Banner status diagnosis dan kondisi kesehatan tanaman
/// Hasil refactoring Temuan Audit 2 (Modularisasi komponen tampilan PlantDetailScreen).
class PlantStatusBanner extends StatelessWidget {
  final PlantModel plant;
  final bool hasScans;
  final bool hasValidDiagnosis;
  final ScanRecordModel? latestScan;

  const PlantStatusBanner({
    super.key,
    required this.plant,
    required this.hasScans,
    required this.hasValidDiagnosis,
    required this.latestScan,
  });

  @override
  Widget build(BuildContext context) {
    Color bg;
    Color textColor;
    IconData icon;
    String text;

    if (!hasScans) {
      // Kondisi 1: Tanaman baru tanpa riwayat scan
      bg = const Color(0xFFF1F5F9);
      textColor = AppColors.textSecondary;
      icon = Icons.info_outline_rounded;
      text = 'Belum ada hasil pemindaian';
    } else if (!hasValidDiagnosis) {
      // Kondisi 2: Ada pemindaian, namun hasil diagnosis AI belum tersedia
      bg = const Color(0xFFEFF6FF);
      textColor = const Color(0xFF1D4ED8);
      icon = Icons.hourglass_top_rounded;
      text = 'Diagnosis belum tersedia • Menunggu analisis';
    } else {
      // Kondisi 3: Diagnosis valid yang benar-benar tersimpan
      final diag = latestScan!.diagnosisName!;
      final isHealthy = latestScan!.severity == 'Sehat' || diag == 'Daun Sehat' || plant.status == 'Sehat';
      final isSevere = latestScan!.severity == 'Parah' || plant.status == 'Parah';

      if (isHealthy) {
        bg = AppColors.greenBadgeBackground;
        textColor = AppColors.greenBadgeText;
        icon = Icons.check_circle_outline_rounded;
        text = 'Kondisi Tanaman Sehat';
      } else if (isSevere) {
        bg = AppColors.redBadgeBackground;
        textColor = AppColors.redBadgeText;
        icon = Icons.warning_amber_rounded;
        text = '$diag • Butuh Penanganan Segera';
      } else {
        bg = AppColors.yellowBadgeBackground;
        textColor = AppColors.yellowBadgeText;
        icon = Icons.warning_amber_rounded;
        text = '$diag • Dalam Rawat';
      }
    }

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        children: [
          Icon(icon, color: textColor, size: 18),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              text,
              style: TextStyle(
                color: textColor,
                fontSize: 13,
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
