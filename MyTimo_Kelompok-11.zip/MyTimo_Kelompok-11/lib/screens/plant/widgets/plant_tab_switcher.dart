import 'package:flutter/material.dart';
import '../../../theme/app_colors.dart';
import '../../../theme/app_sizes.dart';

/// Widget pengalih tab pada detail tanaman ('Ringkasan', 'Riwayat', 'Rencana', 'Monitor')
/// Hasil refactoring Temuan Audit 2.
class PlantTabSwitcher extends StatelessWidget {
  final int activeTab;
  final ValueChanged<int> onTabSelected;

  const PlantTabSwitcher({
    super.key,
    required this.activeTab,
    required this.onTabSelected,
  });

  @override
  Widget build(BuildContext context) {
    const tabs = ['Ringkasan', 'Riwayat', 'Rencana', 'Monitor'];

    return Container(
      height: 40,
      decoration: BoxDecoration(
        color: const Color(0xFFF1F5F1),
        borderRadius: BorderRadius.circular(AppSizes.radiusFull),
      ),
      padding: const EdgeInsets.all(3),
      child: Row(
        children: List.generate(tabs.length, (index) {
          final isSelected = activeTab == index;
          return Expanded(
            child: GestureDetector(
              onTap: () => onTabSelected(index),
              child: Container(
                decoration: BoxDecoration(
                  color: isSelected ? AppColors.primaryGreen : Colors.transparent,
                  borderRadius: BorderRadius.circular(AppSizes.radiusFull),
                ),
                alignment: Alignment.center,
                child: Text(
                  tabs[index],
                  style: TextStyle(
                    color: isSelected ? Colors.white : AppColors.textSecondary,
                    fontWeight: isSelected ? FontWeight.w700 : FontWeight.w500,
                    fontSize: 12.5,
                  ),
                ),
              ),
            ),
          );
        }),
      ),
    );
  }
}
