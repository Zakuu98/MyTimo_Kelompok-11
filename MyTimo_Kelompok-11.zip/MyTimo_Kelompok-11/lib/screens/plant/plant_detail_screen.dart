import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../models/plant_model.dart';
import '../../providers/plant_provider.dart';
import '../../providers/scan_provider.dart';
import '../../theme/app_colors.dart';
import '../../theme/app_sizes.dart';
import '../scan/scan_camera_screen.dart';
import '../scan/scan_history_detail_screen.dart';
import '../scan/scan_history_screen.dart';
import 'add_edit_plant_screen.dart';
import 'utils/plant_health_helper.dart';
import 'widgets/plant_delete_dialog.dart';
import 'widgets/plant_specs_grid.dart';
import 'widgets/plant_status_banner.dart';
import 'widgets/plant_tab_switcher.dart';

/// Halaman Detail Tanaman dan Dialog Konfirmasi Hapus sesuai Screenshot 4.1 dan 4.2
class PlantDetailScreen extends StatefulWidget {
  final String plantId;

  const PlantDetailScreen({super.key, required this.plantId});

  @override
  State<PlantDetailScreen> createState() => _PlantDetailScreenState();
}

class _PlantDetailScreenState extends State<PlantDetailScreen> {
  int _activeTab = 0; // 0: Ringkasan, 1: Riwayat, 2: Rencana, 3: Monitor
  bool _isFavorite = false;

  void _showDeleteConfirmation(BuildContext context, PlantModel plant) {
    PlantDeleteDialog.show(context, plant);
  }

  @override
  Widget build(BuildContext context) {
    final plantProvider = context.watch<PlantProvider>();
    final plant = plantProvider.getPlantById(widget.plantId);

    if (plant == null) {
      return Scaffold(
        appBar: AppBar(title: const Text('Detail Tanaman')),
        body: const Center(child: Text('Data tanaman tidak ditemukan')),
      );
    }

    final scanProvider = context.watch<ScanProvider>();
    final plantScans = scanProvider.getScansForPlant(plant.id);
    final latestScan = scanProvider.getLatestScanForPlant(plant.id);

    // Evaluasi riwayat pemindaian dan status diagnosis menggunakan PlantHealthHelper
    final bool hasScans = PlantHealthHelper.hasScans(plantScans);
    final bool hasValidDiagnosis = PlantHealthHelper.hasValidDiagnosis(latestScan);
    final String healthScoreDisplay = PlantHealthHelper.formatHealthScore(
      plant: plant,
      scans: plantScans,
      latestScan: latestScan,
    );

    return Scaffold(
      backgroundColor: AppColors.surface,
      body: Stack(
        children: [
          // Scrollable Content
          SingleChildScrollView(
            child: Column(
              children: [
                // Area Placeholder Header Sederhana (Menggantikan foto tomat/stok gambar)
                Container(
                  height: 220,
                  width: double.infinity,
                  decoration: const BoxDecoration(
                    gradient: LinearGradient(
                      colors: [
                        Color(0xFFE8F5E9),
                        Color(0xFFD4ECD5),
                      ],
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                    ),
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const SizedBox(height: 24),
                      Container(
                        width: 64,
                        height: 64,
                        decoration: BoxDecoration(
                          color: Colors.white,
                          shape: BoxShape.circle,
                          boxShadow: [
                            BoxShadow(
                              color: AppColors.primaryGreen.withValues(alpha: 0.12),
                              blurRadius: 16,
                              offset: const Offset(0, 4),
                            ),
                          ],
                        ),
                        child: const Icon(
                          Icons.eco_rounded,
                          color: AppColors.primaryGreen,
                          size: 32,
                        ),
                      ),
                      const SizedBox(height: 10),
                      const Text(
                        'Belum ada foto tanaman',
                        style: TextStyle(
                          fontSize: 13.5,
                          fontWeight: FontWeight.w600,
                          color: AppColors.textSecondary,
                        ),
                      ),
                    ],
                  ),
                ),

                // Curved White Details Sheet
                Transform.translate(
                  offset: const Offset(0, -24),
                  child: Container(
                    decoration: const BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.vertical(top: Radius.circular(32)),
                    ),
                    padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 24),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        // Plant Title & HST
                        Text(
                          plant.name,
                          style: const TextStyle(
                            fontSize: 22,
                            fontWeight: FontWeight.w800,
                            color: AppColors.textPrimary,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          '${plant.variety} • Umur ${plant.hstLabel}',
                          style: const TextStyle(
                            fontSize: 13.5,
                            color: AppColors.textSecondary,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                        const SizedBox(height: 14),

                        // Status Badge Banner (Refactored using PlantStatusBanner)
                        PlantStatusBanner(
                          plant: plant,
                          hasScans: hasScans,
                          hasValidDiagnosis: hasValidDiagnosis,
                          latestScan: latestScan,
                        ),
                        const SizedBox(height: 18),

                        // Detail Tab Bar (Refactored using PlantTabSwitcher)
                        PlantTabSwitcher(
                          activeTab: _activeTab,
                          onTabSelected: (index) => setState(() => _activeTab = index),
                        ),
                        const SizedBox(height: 20),

                        // Specs 2x2 Grid Cards (Refactored using PlantSpecsGrid)
                        PlantSpecsGrid(
                          plant: plant,
                          healthScoreDisplay: healthScoreDisplay,
                        ),
                        const SizedBox(height: 24),

                        // Section Scan Terakhir
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            const Text(
                              'Scan Terakhir',
                              style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.w800,
                                color: AppColors.textPrimary,
                              ),
                            ),
                            GestureDetector(
                              onTap: () {
                                Navigator.of(context).push(
                                  MaterialPageRoute(
                                    builder: (_) => ScanHistoryScreen(filterPlantId: plant.id),
                                  ),
                                );
                              },
                              child: const Text(
                                'Lihat Semua',
                                style: TextStyle(
                                  fontSize: 13,
                                  fontWeight: FontWeight.w700,
                                  color: AppColors.primaryGreen,
                                ),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 12),

                        // Scan Terakhir Card
                        if (latestScan != null)
                          GestureDetector(
                            onTap: () {
                              Navigator.of(context).push(
                                MaterialPageRoute(
                                  builder: (_) => ScanHistoryDetailScreen(scanId: latestScan.id),
                                ),
                              );
                            },
                            child: Container(
                              padding: const EdgeInsets.all(12),
                              decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(16),
                                border: Border.all(color: AppColors.border),
                                boxShadow: const [
                                  BoxShadow(
                                    color: Color(0x06000000),
                                    blurRadius: 8,
                                    offset: Offset(0, 2),
                                  ),
                                ],
                              ),
                              child: Row(
                                children: [
                                  ClipRRect(
                                    borderRadius: BorderRadius.circular(12),
                                    child: SizedBox(
                                      width: 48,
                                      height: 48,
                                      child: latestScan.isAssetImage
                                          ? Image.asset(
                                              latestScan.imagePath,
                                              fit: BoxFit.cover,
                                              errorBuilder: (context, error, stackTrace) =>
                                                  _buildScanThumbnailPlaceholder(),
                                            )
                                          : Image.network(
                                              latestScan.imagePath,
                                              fit: BoxFit.cover,
                                              errorBuilder: (context, error, stackTrace) =>
                                                  _buildScanThumbnailPlaceholder(),
                                            ),
                                    ),
                                  ),
                                  const SizedBox(width: 12),
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          latestScan.formattedDateTime,
                                          style: const TextStyle(
                                            fontSize: 14,
                                            fontWeight: FontWeight.w700,
                                            color: AppColors.textPrimary,
                                          ),
                                        ),
                                        const SizedBox(height: 2),
                                        Text(
                                          latestScan.diagnosisName != null
                                              ? '${latestScan.diagnosisName} • ${latestScan.confidence != null ? '${latestScan.confidence!.toStringAsFixed(1)}% akurat' : 'Teridentifikasi'}'
                                              : 'Menunggu Diagnosis AI • Foto tersimpan',
                                          style: const TextStyle(
                                            fontSize: 12,
                                            color: AppColors.textSecondary,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  const Icon(Icons.chevron_right_rounded, color: AppColors.textMuted),
                                ],
                              ),
                            ),
                          )
                        else
                          Container(
                            padding: const EdgeInsets.all(16),
                            decoration: BoxDecoration(
                              color: const Color(0xFFF9FAF9),
                              borderRadius: BorderRadius.circular(14),
                              border: Border.all(color: AppColors.border),
                            ),
                            child: const Center(
                              child: Text(
                                'Belum ada pemindaian untuk tanaman ini',
                                style: TextStyle(color: AppColors.textSecondary, fontSize: 13),
                              ),
                            ),
                          ),

                        const SizedBox(height: 28),

                        // Action 1: Pindai Daun Tanaman Ini
                        SizedBox(
                          width: double.infinity,
                          height: 50,
                          child: ElevatedButton(
                            onPressed: () {
                              Navigator.of(context).push(
                                MaterialPageRoute(
                                  builder: (_) => ScanCameraScreen(selectedPlant: plant),
                                ),
                              );
                            },
                            style: ElevatedButton.styleFrom(
                              backgroundColor: AppColors.primaryGreen,
                              foregroundColor: Colors.white,
                              elevation: 0,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(AppSizes.radiusFull),
                              ),
                            ),
                            child: const Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(Icons.camera_alt_outlined, size: 20),
                                SizedBox(width: 8),
                                Text(
                                  'Pindai Daun Tanaman Ini',
                                  style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700),
                                ),
                              ],
                            ),
                          ),
                        ),
                        const SizedBox(height: 12),

                        // Action 2: Hapus Data Tanaman
                        SizedBox(
                          width: double.infinity,
                          height: 50,
                          child: OutlinedButton(
                            onPressed: () => _showDeleteConfirmation(context, plant),
                            style: OutlinedButton.styleFrom(
                              backgroundColor: const Color(0xFFFFF5F5),
                              side: const BorderSide(color: Color(0xFFFFCDD2), width: 1.2),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(AppSizes.radiusFull),
                              ),
                            ),
                            child: const Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(Icons.delete_outline_rounded, color: AppColors.tomatoRed, size: 20),
                                SizedBox(width: 8),
                                Text(
                                  'Hapus Data Tanaman',
                                  style: TextStyle(
                                    color: AppColors.tomatoRed,
                                    fontSize: 15,
                                    fontWeight: FontWeight.w700,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        const SizedBox(height: 40),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),

          // Top Floating Navigation Bar (Back, Heart, Edit)
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  // Back Button
                  GestureDetector(
                    onTap: () => Navigator.pop(context),
                    child: Container(
                      width: 40,
                      height: 40,
                      decoration: BoxDecoration(
                        color: Colors.white,
                        shape: BoxShape.circle,
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withValues(alpha: 0.08),
                            blurRadius: 8,
                            offset: const Offset(0, 2),
                          ),
                        ],
                      ),
                      child: const Icon(Icons.arrow_back_rounded, color: AppColors.textPrimary, size: 20),
                    ),
                  ),

                  // Right Actions (Edit & Favorite)
                  Row(
                    children: [
                      GestureDetector(
                        onTap: () {
                          Navigator.of(context).push(
                            MaterialPageRoute(
                              builder: (_) => AddEditPlantScreen(plantToEdit: plant),
                            ),
                          );
                        },
                        child: Container(
                          width: 40,
                          height: 40,
                          margin: const EdgeInsets.only(right: 8),
                          decoration: BoxDecoration(
                            color: Colors.white,
                            shape: BoxShape.circle,
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black.withValues(alpha: 0.08),
                                blurRadius: 8,
                                offset: const Offset(0, 2),
                              ),
                            ],
                          ),
                          child: const Icon(Icons.edit_outlined, color: AppColors.textPrimary, size: 20),
                        ),
                      ),
                      GestureDetector(
                        onTap: () {
                          setState(() {
                            _isFavorite = !_isFavorite;
                          });
                        },
                        child: Container(
                          width: 40,
                          height: 40,
                          decoration: BoxDecoration(
                            color: Colors.white,
                            shape: BoxShape.circle,
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black.withValues(alpha: 0.08),
                                blurRadius: 8,
                                offset: const Offset(0, 2),
                              ),
                            ],
                          ),
                          child: Icon(
                            _isFavorite ? Icons.favorite_rounded : Icons.favorite_outline_rounded,
                            color: _isFavorite ? AppColors.tomatoRed : AppColors.textPrimary,
                            size: 20,
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }



  Widget _buildScanThumbnailPlaceholder() {
    return Container(
      color: const Color(0xFFF1F5F9),
      child: const Center(
        child: Icon(Icons.image_outlined, color: AppColors.textMuted, size: 20),
      ),
    );
  }
}
