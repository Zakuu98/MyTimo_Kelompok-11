import '../../../models/plant_model.dart';
import '../../../models/scan_record_model.dart';

/// Helper logika evaluasi dan pemformatan skor kesehatan tanaman
/// Hasil refactoring Temuan Audit 2 (Ekstraksi logika bisnis dari lifecycle method build).
class PlantHealthHelper {
  /// Memeriksa apakah tanaman memiliki riwayat pemindaian
  static bool hasScans(List<ScanRecordModel> scans) => scans.isNotEmpty;

  /// Memeriksa apakah diagnosis pemindaian terakhir valid dan telah selesai diproses oleh AI
  static bool hasValidDiagnosis(ScanRecordModel? latestScan) {
    return latestScan != null &&
        latestScan.diagnosisName != null &&
        latestScan.diagnosisName!.trim().isNotEmpty &&
        latestScan.status != 'Menunggu Diagnosis AI';
  }

  /// Menghitung dan memformat teks tampilan skor kesehatan secara deterministik
  static String formatHealthScore({
    required PlantModel plant,
    required List<ScanRecordModel> scans,
    ScanRecordModel? latestScan,
  }) {
    if (!hasScans(scans)) {
      return 'Belum tersedia';
    }
    if (!hasValidDiagnosis(latestScan)) {
      return 'Diagnosis belum tersedia';
    }

    final scan = latestScan!;
    if (scan.confidence != null) {
      final severityText = scan.severity == 'Sehat' ? 'Sehat' : scan.severity;
      return '${scan.confidence!.toStringAsFixed(0)}% • $severityText';
    } else if (plant.healthScore != null) {
      return '${plant.healthScore}% • ${plant.status}';
    } else {
      return scan.diagnosisName!;
    }
  }
}
