import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/navigation_provider.dart';
import '../theme/app_colors.dart';
import 'home/home_screen.dart';
import 'plant/plant_list_screen.dart';
import 'scan/scan_camera_screen.dart';
import 'scan/scan_history_screen.dart';

/// Main Navigation Screen with 5 Tabs and Center Elevated Scan Button matching Screenshots
class MainNavigationScreen extends StatelessWidget {
  const MainNavigationScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Consumer<NavigationProvider>(
      builder: (context, nav, _) {
        return Scaffold(
          body: IndexedStack(
            index: nav.currentIndex,
            children: const [
              HomeScreen(),
              PlantListScreen(),
              SizedBox.shrink(), // Dummy for center button
              ScanHistoryScreen(),
              _PlaceholderMonitorTab(),
            ],
          ),
          bottomNavigationBar: Container(
            decoration: BoxDecoration(
              color: Colors.white,
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withValues(alpha: 0.08),
                  blurRadius: 16,
                  offset: const Offset(0, -4),
                ),
              ],
            ),
            child: SafeArea(
              top: false,
              child: SizedBox(
                height: 66,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    // Tab 1: Beranda
                    _buildNavItem(
                      context,
                      label: 'Beranda',
                      icon: Icons.home_rounded,
                      isActive: nav.currentIndex == 0,
                      onTap: () => nav.setIndex(0),
                    ),

                    // Tab 2: Tanaman
                    _buildNavItem(
                      context,
                      label: 'Tanaman',
                      icon: Icons.spa_outlined,
                      isActive: nav.currentIndex == 1,
                      onTap: () => nav.setIndex(1),
                    ),

                    // Tab 3: Center Elevated Scan Button (Pindai)
                    GestureDetector(
                      onTap: () {
                        Navigator.of(context).push(
                          MaterialPageRoute(
                            builder: (_) => const ScanCameraScreen(),
                          ),
                        );
                      },
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Container(
                            width: 44,
                            height: 44,
                            decoration: BoxDecoration(
                              gradient: AppColors.orangeScannerGradient,
                              shape: BoxShape.circle,
                              boxShadow: [
                                BoxShadow(
                                  color: AppColors.orangeAccent.withValues(alpha: 0.4),
                                  blurRadius: 8,
                                  offset: const Offset(0, 3),
                                ),
                              ],
                            ),
                            child: const Icon(
                              Icons.crop_free_rounded,
                              color: Colors.white,
                              size: 22,
                            ),
                          ),
                          const SizedBox(height: 2),
                          const Text(
                            'Pindai',
                            style: TextStyle(
                              fontSize: 10.0,
                              fontWeight: FontWeight.w700,
                              color: AppColors.orangeDeep,
                            ),
                          ),
                        ],
                      ),
                    ),

                    // Tab 4: Riwayat
                    _buildNavItem(
                      context,
                      label: 'Riwayat',
                      icon: Icons.access_time_rounded,
                      isActive: nav.currentIndex == 3,
                      onTap: () => nav.setIndex(3),
                    ),

                    // Tab 5: Monitor
                    _buildNavItem(
                      context,
                      label: 'Monitor',
                      icon: Icons.show_chart_rounded,
                      isActive: nav.currentIndex == 4,
                      onTap: () => nav.setIndex(4),
                    ),
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildNavItem(
    BuildContext context, {
    required String label,
    required IconData icon,
    required bool isActive,
    required VoidCallback onTap,
  }) {
    final color = isActive ? AppColors.primaryGreen : AppColors.textMuted;

    return InkWell(
      onTap: onTap,
      splashColor: AppColors.primaryGreenSoft.withValues(alpha: 0.3),
      highlightColor: Colors.transparent,
      borderRadius: BorderRadius.circular(12),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, color: color, size: 24),
            const SizedBox(height: 3),
            Text(
              label,
              style: TextStyle(
                fontSize: 10.5,
                fontWeight: isActive ? FontWeight.w700 : FontWeight.w500,
                color: color,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _PlaceholderMonitorTab extends StatelessWidget {
  const _PlaceholderMonitorTab();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF8FAF8),
      appBar: PreferredSize(
        preferredSize: const Size.fromHeight(60),
        child: Container(
          decoration: const BoxDecoration(
            gradient: AppColors.primaryGreenGradient,
          ),
          child: const SafeArea(
            child: Padding(
              padding: EdgeInsets.symmetric(horizontal: 20, vertical: 16),
              child: Text(
                'Monitoring Kebun',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 18,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
          ),
        ),
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                padding: const EdgeInsets.all(22),
                decoration: const BoxDecoration(
                  color: Color(0xFFFFEBEE),
                  shape: BoxShape.circle,
                ),
                child: const Icon(Icons.show_chart_rounded, size: 52, color: AppColors.tomatoRed),
              ),
              const SizedBox(height: 18),
              const Text(
                'Plant Monitoring & Analysis',
                style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800),
              ),
              const SizedBox(height: 8),
              const Text(
                'Modul monitoring perkembangan tanaman dan analisis tren penyakit tomat (Workflow Anggota 4).',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 13, color: AppColors.textSecondary, height: 1.4),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
